---
title: ctrl-exec - Installation and Operations
subtitle: Platform requirements, setup, configuration, and operational reference
brand: odcc
---


This document is the authoritative reference for all `ctrl-exec-dispatcher` and
`ctrl-exec-agent` commands. It covers every mode, option, and environment
variable for both binaries.

For installation and initial setup, see INSTALL.md. For a hands-on
introduction to what the system can do, run the ctrl-exec-demonstrator
script on a paired agent - see INSTALL.md for instructions on enabling it.

## ctrl-exec-dispatcher

The `ctrl-exec-dispatcher` binary runs on the dispatcher host. It manages the CA,
handles agent pairing, and dispatches commands to paired agents.

### Synopsis

```bash
ctrl-exec-dispatcher <mode> [options] [args]
```

### Global options

These options apply to all modes.

`--config <path>`
: Path to `ctrl-exec.conf`. Default: `/etc/ctrl-exec/ctrl-exec.conf`.

`--port <n>`
: Override the default agent port (7443) for all hosts in this invocation.
  Individual hosts can also override their port with `<host>:<port>` syntax.

`--json`
: Output results as JSON. Applies to `run`, `ping`, and `list-agents`.

`--username <n>`
: Username to include in the request context. Defaults to `$USER`. This is an
  advisory field - it is forwarded to auth hooks and to the agent unchanged,
  but is not authenticated or verified by the dispatcher. Its intended use is to
  carry an identity assertion that the auth hook can forward to an external
  authentication service alongside the token, allowing that service to verify
  whether the claimed identity is consistent with the token's authority. Do
  not use `username` alone as an access control basis. See
  SECURITY-OPERATIONS.md for the recommended pattern.

`--token <token>`
: Auth token to include in the request context. Defaults to the
  `$ENVEXEC_TOKEN` environment variable if set. Consumed by auth hooks
  on the agent side.

### Environment variables

`ENVEXEC_TOKEN`
: Default auth token. Equivalent to `--token`. Useful for scripted or
  automated invocations where passing a token on the command line is
  undesirable.

`USER`
: Default username. Overridden by `--username`.

---

### run

Run an allowlisted script on one or more agents in parallel.

```bash
ced run <host>[:<port>] [<host>...] <script> [-- <arg>...]
```

The script name must match an entry in the agent's `scripts.conf` allowlist.
Everything after `--` is passed to the script as positional arguments.
Arguments are evaluated on the dispatcher host before being sent - use
`--` to pass static strings, not shell expressions intended to run on
the agent.

The dispatcher sends a JSON context object to the script via stdin on the
agent. This includes the script name, username, token, arguments, timestamp,
peer IP, and request ID. See INSTALL.md for the full context structure.

```bash
# Single host
ced run web-01 deploy-app

# Multiple hosts in parallel
ced run web-01 web-02 web-03 deploy-app

# Pass arguments to the script
ced run db-01 backup-mysql -- --database myapp

# Custom port for one host
ced run web-01:7450 deploy-app

# Identify the operator explicitly
ced run web-01 deploy-app --username alice

# Pass an auth token
ced run web-01 deploy-app --token mytoken
ENVEXEC_TOKEN=mytoken ced run web-01 deploy-app

# JSON output
ced run web-01 deploy-app --json
```

Output shows per-host status, exit code, round-trip time, stdout, and stderr.
Exit code is 0 if all hosts succeeded, 1 if any host failed or returned
a non-zero exit.

#### Asynchronous runs (`--async`)

For jobs that run longer than the dispatcher `read_timeout` (default 60s),
submit with `--async`:

```bash
ced run db-01 db-02 long-reindex --async
```

The agent starts the script detached and the command returns immediately
with a request id instead of waiting for output:

```
Submitted async run  req:a1b2c3d4e5f60718
==> db-01  [accepted  12ms]
==> db-02  [accepted  10ms]
Check progress with: ced status a1b2c3d4e5f60718
```

Each host reports `accepted`, `BUSY` (the agent is already running that
script), or `ERROR`. Exit code is 0 if any host accepted, 1 if none did.
Retrieve results later with `status` or `wait` (below). Because the job is
detached (`setsid` + the agent unit's `KillMode=process`), it survives the
connection close and an agent restart; its result is held on the agent and
fetched on demand. Agent-side concurrency still applies: a second async run
of the same script on a host is refused while the first is in flight.

#### Dispatch host resolution

When a host argument matches a registered agent name, both the connect
address and the port are resolved from the registry (set at pairing).

Address, from the agent's `lookup_by` field (see `approve --lookup-by`):

- `hostname` (default): connect to the agent's registered hostname.
- `ip`: connect to the IP recorded at pairing. Use this when the
  agent-reported hostname does not resolve from the dispatcher.

Port, from the agent's `port` field (see `approve --agent-port`): the stored
operational port is used automatically, so an agent on a non-default port is
reachable without passing `--port` each time.

A host argument that is not a registered agent, or one given with an explicit
`host:port`, is used verbatim (DNS resolution and the explicit port as
before) — so ad-hoc and one-off-port targets still work. An explicit
`host:port` overrides the stored port; the global `--port` applies only to
hosts whose port is not otherwise determined. mTLS is unaffected: the agent
certificate is validated against the CA, not matched to the connect address.

The registry name is canonical: `run`, `ping`, and `discovery` display and key
results by the name the agent was addressed by (its registry name), regardless
of the address actually connected to. When the agent reports a different
hostname for itself, that reported name is shown in brackets — for example
`web-01 (vm-7a3f)` — or carried as `reported_hostname` in JSON / discovery
output.

---

### status

Show the current state of an asynchronous run submitted with `run --async`.

```bash
ced status <reqid>
```

On each call the dispatcher fetches results from every host still running,
merges them into the stored record, and prints the per-host state:

```
Request a1b2c3d4e5f60718  (script: long-reindex)  [PENDING]
==> db-01  [done  exit:0]
reindex complete
==> db-02  [running]
```

Per-host states: `done` (with exit code, stdout, stderr), `running` /
`accepted` (still in progress), `EXPIRED` (the agent purged its result
before it was fetched — results live 24h), `BUSY` or `ERROR` (the job never
ran there). The header shows `COMPLETE` once no host is still running.
`--json` emits the full record. Exit code is 0 when the record is found,
1 if the reqid is unknown.

---

### wait

Poll an asynchronous run until it completes, then print the final result.

```bash
ced wait <reqid> [--timeout <seconds>]
```

`wait` repeatedly aggregates `status` (every 2s) until every host has
finished or the timeout elapses (default 300s). Output is the same as
`status`. Exit code:

- `0` — complete, all hosts succeeded (exit 0)
- `1` — complete, but some host failed (non-zero exit, busy, error, or expired)
- `2` — timed out while still pending

This makes `wait` suitable for scripting a submit-then-block flow:

```bash
reqid=$(ced run db-01 db-02 long-reindex --async --json | jq -r .reqid)
ced wait "$reqid" --timeout 600
```

---

### ping

Test mTLS connectivity to one or more agents and report cert expiry and
agent version.

```bash
ced ping <host>[:<port>] [<host>...]
```

```bash
# Single host
ced ping web-01

# Multiple hosts in parallel
ced ping web-01 web-02 web-03

# JSON output
ced ping web-01 --json
```

Output columns: host, status (ok/error), round-trip time, cert expiry,
agent version.

---

### pairing-mode

Start the pairing listener on port 7444. Agents call `request-pairing`
to submit a CSR; this mode receives the request, displays it for operator
approval, and signs and returns the certificate on approval.

```bash
ced pairing-mode
```

The prompt shows the requesting agent's hostname, IP, request ID, and a
6-digit confirmation code. The agent displays the same code at submission
time. Verify both match before approving.
Enter `a` to approve, `d` to deny, or `s` to skip and leave the request
pending. Press Ctrl-C to stop pairing mode.

Pairing mode processes one request at a time interactively. For
unattended approval workflows, use `list-requests` and `approve`.

**Automatic timeout.** Pairing mode always auto-stops after an absolute
timeout so the pairing port cannot be left open indefinitely. The default is
600 seconds; lower it with `--timeout <seconds>` (1–600) or the
`pairing_timeout` config key. The window can be shortened but never extended
beyond 600 seconds.

```bash
ced pairing-mode --timeout 120   # auto-stops after 2 minutes
```

**Background start/stop.** Run the listener detached instead of in the
foreground:

```bash
ced pairing-mode start           # detach; auto-stops at the timeout
ced pairing-mode stop            # stop a backgrounded session, close the port
```

`start` reports the PID and the stop deadline, then returns. Only one
background session runs at a time (tracked by a pidfile under
`/var/lib/ctrl-exec`). `stop` is a no-op, with a clear message, if nothing is
running.

---

### list-requests

List pending pairing requests that have not yet been approved or denied.

```bash
ced list-requests
```

Output columns: request ID, hostname, IP, confirmation code, received timestamp.
Verify the confirmation code matches the 6-digit code displayed on the agent
before approving.

---

### approve

Approve a pending pairing request by ID. Signs the agent's CSR and
delivers the certificate on the agent's next poll.

```bash
ced approve <reqid>
ced approve <reqid> --lookup-by ip
ced approve <reqid> --ip 192.168.1.10
ced approve <reqid> --agent-port 7450
```

The request ID is shown by `list-requests` and `pairing-mode`.

The IP stored for the agent is the address the agent reports for itself at
pairing time (the source address of its connection to the dispatcher). The
dispatcher falls back to the connection's own source IP only if the agent does
not report one — note that source IP is unreliable when a NAT sits in front of
the dispatcher (for example the dispatcher running in a Docker container, where
every agent's connection appears to come from the bridge gateway). Use
`--ip` to set the address explicitly in that case.

`--lookup-by <ip|hostname>`
: How dispatch resolves this agent's connect address (stored in the registry
  as `lookup_by`). `hostname` (default) connects to the agent's registered
  hostname; `ip` connects to the IP recorded at pairing. Use `ip` when the
  agent-reported hostname does not resolve from the dispatcher. This overrides
  any value the agent suggested with `request-pairing --lookup-by`. See
  *Dispatch host resolution* under `run`.

`--ip <addr>`
: The address to record for this agent (registry `ip`), used by dispatch when
  `lookup_by` is `ip`. Overrides the agent's self-reported source IP and the
  connection source IP. Set this when a NAT in front of the dispatcher hides
  the agent's real address. Accepts IPv4 or IPv6.

`--agent-port <n>`
: The agent's operational port, stored in the registry as `port` and used by
  dispatch so the agent is reachable without a per-command `--port`. Overrides
  the port the agent reported at pairing (its configured serve port). Useful
  when the dispatcher reaches the agent on a different port than the agent
  binds — for example a port-mapped container. Default 7443.

---

### deny

Deny a pending pairing request by ID. Removes the request without
signing.

```bash
ced deny <reqid>
```

---

### list-agents

List all registered (paired) agents.

```bash
ced list-agents
ced list-agents --json
ced list-agents --tags env=production
ced list-agents --tags env=production,role=database
```

Output columns: hostname, IP address, operational port, lookup mode, paired
timestamp, cert expiry.

`--tags <key=value[,key=value...]>`
: Filter to agents whose cached tags match every given `key=value` pair (AND).
  Tags are read from the registry cache, not by querying agents live, so the
  filter is fast and works offline. The cache is populated and refreshed by
  `discovery` (which reads each agent's live tags from `/capabilities`); a
  newly paired agent shows no tags until the first discovery against it. Tag
  values are matched exactly; this filter syntax cannot express commas within
  a value. Tags appear in the `--json` output under the `tags` field.

With `--json`, returns an array of objects with fields:

`hostname`
: Agent hostname as registered at pairing time.

`ip`
: IP address of the agent at last contact.

`port`
: The agent's operational port (default 7443). Used by dispatch.

`lookup_by`
: How dispatch resolves this agent: `hostname` (default) or `ip`. See
  *Dispatch host resolution* under `run`.

`tags`
: Object of the agent's key/value tags, cached from `/capabilities` on the
  last `discovery`. Empty `{}` until the first discovery against the agent.
  Used by `--tags`.

`paired_at`
: ISO 8601 timestamp of when the agent was paired.

`cert_expiry`
: ISO 8601 timestamp of the agent certificate's notAfter date.

`serial`
: Truncated hex serial of the agent's current certificate.

---

### edit-agent

Edit a registered agent's dispatch fields, or rename it, without re-pairing.
Only the dispatch-relevant fields are editable; the certificate and serial
tracking are left intact. At least one change flag is required.

```bash
ced edit-agent <name> --ip 10.0.0.42
ced edit-agent <name> --agent-port 7450 --lookup-by ip
ced edit-agent old-name --rename new-name
```

`--rename <new-name>`
: Move the registry entry to a new canonical name. Fails if the new name is
  already in use or is not a valid name (letters, digits, `.`, `-`, `_`;
  must start with a letter or digit).

`--ip <addr>`
: Update the stored address used when `lookup_by = ip`.

`--agent-port <n>`
: Update the stored operational port (1–65535).

`--lookup-by <ip|hostname>`
: Update how dispatch resolves this agent. See *Dispatch host resolution*
  under `run`.

`--json` prints the updated record. The agent's certificate is unaffected;
renaming or re-addressing does not require the agent to re-pair, since mTLS
validates the certificate against the CA rather than the connect address.

---

### setup-ca

One-time initialisation of the dispatcher CA. Generates the CA key and
self-signed certificate used to sign all agent certificates. Run once
on the dispatcher host before any pairing.

```bash
ced setup-ca
```

Writes to `/etc/ctrl-exec/`. Does not overwrite an existing CA.

---

### setup-ctrl-exec

Generate the dispatcher's own key and certificate, signed by the CA.
Run after `setup-ca`. If an existing cert is found and registered agents
exist, the command displays the agent count and requires confirmation before
proceeding - replacing the cert changes its serial. The new serial is then
broadcast to agents over the run channel and added to each reachable agent's
trusted-dispatcher map automatically, so rotation is seamless for agents that
are online; only an agent that is offline during the broadcast and misses it
will need re-pairing.

```bash
ced setup-ctrl-exec
```

Writes to `/etc/ctrl-exec/`.

---

### rotate-cert

Rotate the dispatcher certificate immediately. Generates a new cert, marks
all registered agents as pending, broadcasts the new serial to all agents
in parallel, and reports per-agent results.

```bash
ced rotate-cert
```

Agents that were unreachable during the broadcast are retried automatically
by the internal check loop. Agents that remain unreachable after
`cert_overlap_days` are marked `stale` and require re-pairing.

The broadcast uses the agent's built-in `/rotate-serial` operation, so it
needs no `scripts.conf` allowlist entry — cert rotation is a first-class
control-plane operation, not an allowlisted script.

---

### serial-status

Show the current dispatcher serial, previous serial, rotation timestamps,
overlap expiry, and per-agent serial state.

```bash
ced serial-status
ced serial-status --json
```

Output columns: hostname, status (current/pending/stale/unknown), last
confirmed timestamp, serial (truncated).

Status values:

- `current` - agent has confirmed the current serial
- `pending` - broadcast attempted but not yet confirmed (agent may be offline)
- `stale` - overlap window expired without confirmation; re-pair required
- `unknown` - agent has never received a serial update

---

## ctrl-exec.conf

Configuration file for the dispatcher and ctrl-exec-api processes.
Default path: `/etc/ctrl-exec/ctrl-exec.conf`.

Key settings:

`cert`, `key`, `ca`
: Paths to the dispatcher's TLS certificate, private key, and CA
  certificate. Required for all mTLS operations.

`dispatcher_id`
: Stable identity for this dispatcher. Defaults to the dispatcher
  hostname. Delivered to each agent at pairing and recorded against the
  dispatcher's cert serial in the agent's trusted-dispatcher map. Agent
  permission and attribution key on this id, so it must remain stable
  across cert rotations - set it explicitly if the hostname may change.

  ```
  dispatcher_id = ctrl-exec-primary
  ```

`read_timeout`
: How long (in seconds) the dispatcher waits for a response from an agent
  before reporting a timeout error. Default: 60. The script continues
  running on the agent after a timeout - only the dispatcher's ability to
  receive the output is affected. Raise this value for scripts that are
  expected to take longer than 60 seconds.

  ```
  read_timeout = 120
  ```

`timeout`
: Deprecated alias for `read_timeout`. Accepted for backward compatibility.

`max_parallel`
: Maximum concurrent agent connections per fan-out operation (run/ping/discovery
  over a fleet). Default: 64. Bounds how many TLS clients are forked at once so a
  large fleet does not exhaust file descriptors; hosts beyond the cap queue. Read
  by `Exec::Engine`.

  ```
  max_parallel = 64
  ```

`api_port`
: Port for the `ctrl-exec-api` HTTP server. Default: 7445.

`api_cert`, `api_key`
: TLS certificate and key for the API server. If both are present and
  readable, the API server uses TLS. If absent, plain HTTP is used.

`api_bind`
: Network address the API server binds to. Default: `127.0.0.1` (localhost
  only). Set to `0.0.0.0` to accept connections on all interfaces, or to a
  specific interface address. Only change this if external clients need direct
  access; prefer a reverse proxy for internet-facing deployments.

  ```
  api_bind = 0.0.0.0
  ```

`api_auth_default`
: Controls API behaviour when no `auth_hook` is configured. Accepts `deny`
  (default) or `allow`. With `deny`, all requests are rejected until a hook
  is configured. With `allow`, all requests are authorised without a hook -
  suitable only for isolated networks. When a hook is configured this setting
  has no effect.

  ```
  api_auth_default = allow
  ```

`auth_deny_generic`
: When enabled (`1`/`yes`; default off), the API returns a generic `403`
  with `{"error":"forbidden"}` for denied `run`, `ping`, and `discovery`
  requests, withholding the specific denial reason and code from the caller
  to reduce information disclosure. The full reason is still logged
  server-side. Off returns the detailed reason and code.

  ```
  auth_deny_generic = 1
  ```

### Cert rotation settings

`cert_days`
: Lifetime of the dispatcher certificate in days. Default: 365. Applied when
  generating a new cert via `setup-ctrl-exec` or automatic rotation.

`cert_renewal_days`
: Begin renewal this many days before the dispatcher cert expires. Default: 90.
  With `cert_days = 365`, renewal begins at day 275 of the cert's life.

`cert_overlap_days`
: After rotation, continue retrying agents that missed the serial broadcast for
  this many days before marking them `stale` (requiring re-pair). Default: 30.
  Configurable to accommodate fleets with agents that are offline for extended
  periods.

  ```
  cert_overlap_days = 60
  ```

`cert_check_interval`
: Seconds between internal cert expiry checks. Default: 14400 (4 hours). Reduce
  for testing. The check is lightweight: read the cert, compare notAfter to now.

`auth_hook`
: Path to an executable called before every `run` and `ping` operation.
  Receives request context as JSON on stdin. See INSTALL.md for the full
  interface contract.

---

## agent.conf

Configuration file for the `ctrl-exec-agent` process.
Default path: `/etc/ctrl-exec-agent/agent.conf`.

Key settings:

`port`
: Port the agent listens on for mTLS connections from the dispatcher. Default: 7443.

`cert`, `key`, `ca`
: Paths to the agent's TLS certificate, private key, and CA certificate.

`revoked_serials`
: Path to a file listing revoked TLS certificate serial numbers, one per line.
  Connections presenting a revoked cert are rejected immediately after the mTLS
  handshake, before any request is processed. Reloaded on SIGHUP without restart.

  Accepted serial formats (all normalised to lowercase hex on load):

  - Plain hex: `deadbeef`
  - Colon-separated: `DE:AD:BE:EF` (as returned by some tools and `IO::Socket::SSL`)
  - `0x`-prefixed: `0xdeadbeef`
  - `serial=`-prefixed: `serial=DEADBEEF` (as output by `openssl x509 -serial`)
  - Decimal integer: `3735928559`

  Lines beginning with `#` are treated as comments.

  Default: `/etc/ctrl-exec-agent/revoked-serials`. A missing or empty file
  means no certs are revoked.

  ```
  revoked_serials = /etc/ctrl-exec-agent/revoked-serials
  ```

`trusted_dispatchers_path`
: Path to the trusted-dispatcher map. Each line maps a dispatcher cert
  serial to a dispatcher id: `<hex-serial> <dispatcher-id>`. Written
  automatically by `request-pairing` and updated in place during cert
  rotation - do not edit manually. Pairing appends an entry, so an agent can
  serve multiple dispatchers natively; re-pair to add another. The `/run`,
  `/ping`, `/result`, and `/capabilities` endpoints reject peers whose cert
  serial is not a key in the map; the matched dispatcher identity drives
  permission and attribution. A dispatcher cert rotation updates the map
  automatically over the run channel (the rotated serial is added, then the
  old serial removed after the overlap window), so no re-pairing is needed
  for a reachable agent.

  Default: `/var/lib/ctrl-exec-agent/ctrl-exec-dispatchers`. The map lives in
  the agent-writable state directory, not the root-owned config dir, so the
  non-root agent service user can rewrite it in place during cert rotation.
  Reloaded on SIGHUP.

`dispatcher_cn`
: Removed. Previously used to restrict `/capabilities` by cert CN. Replaced
  by the trusted-dispatcher map via `trusted_dispatchers_path`.

`script_dirs`
: Colon-separated list of absolute directory paths. If set, any script in
  `scripts.conf` whose path does not fall under one of these directories is
  rejected at load time and re-validated at execution time.

  ```
  script_dirs = /opt/ctrl-exec-scripts:/usr/local/lib/ctrl-exec-scripts
  ```

`auth_hook`
: Path to an executable called before every `run` request on the agent,
  after allowlist validation. Enables independent downstream token validation
  separate from the dispatcher's own hook.

  The hook receives request context as a JSON object on stdin and as individual
  environment variables. Exit codes:

  - `0` - authorised, request proceeds
  - `1` - denied (generic refusal)
  - `2` - bad credentials (token not recognised or expired)
  - `3` - insufficient privilege (credentials valid but not permitted for this script)

  If no hook is configured, the request is authorised unconditionally - the agent
  relies on mTLS for identity; the hook is for additional policy enforcement only.

  See the [Auth hook (agent-side)] section under `ctrl-exec-agent` for context
  fields, environment variables, and differences from the dispatcher-side hook.

`pairing_port`
: Port the agent listens on during pairing. Default: 7444. Must match the
  `--port` value passed to `ctrl-exec-agent request-pairing` and the port
  used by `ced pairing-mode`.

  ```
  pairing_port = 7444
  ```

`pairing_max_queue`
: Maximum number of pairing requests held in the queue at one time. When
  the limit is reached, incoming requests are rejected immediately with
  `ACTION=pair-reject REASON=queue-full`. Default: 10. Raise this value
  only on deployments where many agents are paired concurrently; the queue
  is normally short-lived as each request is approved or denied within
  seconds.

  ```
  pairing_max_queue = 10
  ```

`allowed_ips`
: Comma-separated list of IP addresses or CIDR prefixes (/8, /16, /24)
  permitted to connect to the agent's mTLS port. Connections from addresses
  not on the list are dropped immediately after the TCP accept, before the
  TLS handshake. If unset, all source addresses are accepted.

  ```
  allowed_ips = 192.168.1.0/24, 10.0.0.1
  ```

  Invalid entries are logged as `ACTION=config-warn` at load time and
  silently skipped.

### Rate limiting settings

The agent applies two independent rate limits per source IP. Both are
tracked in memory and reset on agent restart or SIGHUP.

**Trusted dispatchers are exempt from the volume threshold** (since 0.12.4).
The accept loop reads the peer certificate serial before the rate check; a
serial present in the trusted-dispatcher map (`trusted_dispatchers_path`, written
at pairing) identifies a dispatcher whose every request will be served anyway,
and its connections are not counted. Every run, ping, result poll and
discovery is a separate connection, so without the exemption ~10 operations
in a minute from the one paired dispatcher tripped a 5-minute block. The
volume threshold therefore governs CA-signed-but-unpaired peers; the probe
threshold, `max_children` and `allowed_ips` apply to everyone.

A blocked peer receives `HTTP/1.0 429 Too Many Requests` with a JSON body
`{"status":"error","error":"rate limited","retry_after":<seconds>}` before the
connection is closed (earlier releases closed it silently, which the
dispatcher reported as `no response from child`).

The volume threshold blocks IPs that open an unusually high number of
connections in a short window — consistent with port scanning or connection
flooding. The probe threshold blocks IPs that repeatedly fail TLS
handshakes — consistent with certificate probing or brute-force attempts.

`rate_limit_volume`
: Volume threshold in the format `limit/window/block`. Blocks a source IP
  for `block` seconds when it opens more than `limit` connections within
  `window` seconds. Default: `10/60/300` (10 connections in 60 seconds
  triggers a 5-minute block).

  ```
  rate_limit_volume = 10/60/300
  ```

`rate_limit_probe`
: Probe threshold in the format `limit/window/block`. Blocks a source IP
  for `block` seconds when it produces more than `limit` TLS handshake
  failures within `window` seconds. Default: `3/600/3600` (3 failures in
  10 minutes triggers a 1-hour block).

  ```
  rate_limit_probe = 3/600/3600
  ```

`rate_limit_disable`
: Set to `1` to disable all rate limiting. Intended for use during the
  integration test suite, which opens many connections rapidly from
  localhost. Do not set in production. (This is the key name `Config.pm`
  reads; `disable_rate_limit` is not recognised.) Since 0.12.4 the paired
  dispatcher is exempt from the volume threshold, so the suite's own
  dispatcher no longer needs this unless it also exercises unpaired peers.

  ```
  rate_limit_disable = 1
  ```

### Agent tags

Arbitrary key/value metadata attached to the agent and returned in the
`/capabilities` response. Used by the API and any tooling that queries
agent capabilities to filter or label agents by environment, role, or
location without requiring separate inventory.

Defined in a `[tags]` section in `agent.conf`:

```ini
[tags]
env = production
role = database
location = ams1
```

Tags are returned as a JSON object in the `tags` field of the
`/capabilities` response:

```json
{
  "status": "ok",
  "host": "db1.example.com",
  "version": "1.0.0",
  "scripts": [...],
  "tags": { "env": "production", "role": "database", "location": "ams1" }
}
```

Tag keys and values are arbitrary strings. No reserved keys. An agent
with no `[tags]` section returns `"tags": {}`.

### Script schema sidecars

Each allowlisted script may have an optional schema sidecar describing its
arguments, so tools that consume the API can type each script. The agent
looks for a file beside the script with `.schema.json` appended:

```
/opt/ctrl-exec-scripts/check-disk.sh
/opt/ctrl-exec-scripts/check-disk.sh.schema.json   ← optional sidecar
```

The sidecar is a JSON object holding a JSON Schema for the script's arguments
plus protocol-neutral metadata (`description`, and the behavioural flags
`read_only` / `destructive` / `idempotent`):

```json
{
  "version": "2",
  "description": "Check disk usage against a threshold",
  "read_only": true,
  "arguments": {
    "type": "object",
    "properties": { "threshold": { "type": "integer", "minimum": 1, "maximum": 100 } }
  },
  "argv": [ { "arg": "threshold" } ]
}
```

When present, the agent advertises it in the `/capabilities` response as
`schema` plus a derived `schema_version` (the explicit `version`, or a
content hash), and `/discovery` and `/openapi-live.json` carry it through.
The MCP bridge consumes this to expose each script as a typed tool; it is also
usable by a UI or for argument validation.

The sidecar is read **only for allowlisted scripts**, capped at 64 KiB, and
reloaded on SIGHUP with the allowlist. A missing, oversize, or invalid sidecar
is skipped (logged as `ACTION=schema-skip`) — the script stays callable, just
untyped. The agent never executes or interprets the sidecar; it only advertises
it. See `docs/SCHEMA-SIDECAR.md` for the full format, the version-identity
rule, and the cross-host version-collision behaviour.

---

## ctrl-exec-agent

The `ctrl-exec-agent` binary runs on each managed host. It serves the
mTLS listener, handles pairing, and executes allowlisted scripts on
request from the dispatcher.

### Synopsis

```bash
ctrl-exec-agent <mode> [options]
```

### Global options

`--config <path>`
: Path to `agent.conf`. Default: `/etc/ctrl-exec-agent/agent.conf`.

`--allowlist <path>`
: Path to `scripts.conf`. Default: `/etc/ctrl-exec-agent/scripts.conf`.

`--port <n>`
: Override the pairing port (default 7444). Applies to `request-pairing`
  only; the serve port is set in `agent.conf`.

---

### serve

Start the agent server. Listens on the port configured in `agent.conf`
(default 7443) for incoming mTLS connections from the dispatcher.

```bash
ctrl-exec-agent serve
```

Under normal operation this is started and managed by the init system
(systemd or procd). Run directly for debugging or on systems without
a supported init system.

The agent reloads `scripts.conf` and the revocation list on SIGHUP without
restarting:

```bash
# On systemd hosts (preferred)
systemctl reload ctrl-exec-agent

# On systems without systemd
kill -HUP $(pidof ctrl-exec-agent)
```

---

### request-pairing

Submit a pairing request to a dispatcher host. Generates a key and CSR
for this agent, connects to the dispatcher's pairing port (7444), and
waits for the operator to approve the request. The agent's configured
operational port (`port` in `agent.conf`, default 7443) is reported in the
request and stored in the registry so dispatch can reach it without a
per-command `--port`; the operator can override it with `approve --agent-port`.

```bash
ctrl-exec-agent request-pairing --dispatcher <host>
ctrl-exec-agent request-pairing --dispatcher <host> --background [--timeout <n>]
```

`--dispatcher <host>`
: Hostname or IP of the dispatcher host. Required.

`--port <n>`
: Override the pairing port on the dispatcher (default 7444).

`--lookup-by <ip|hostname>`
: Suggest how the dispatcher should resolve this agent for dispatch
  (default: `hostname`). Sent with the pairing request; the operator's
  `approve --lookup-by` overrides it. See *Dispatch host resolution* under
  `ced run`.

`--background`
: Non-interactive mode for orchestrated installations. Prints the request
  ID to stdout and exits immediately, leaving a background process to wait
  for approval and store the certificate on receipt. See
  [Orchestrated pairing](#orchestrated-pairing) below.

`--timeout <n>`
: How long (in seconds) the background process waits for approval before
  giving up. Default: 30. Maximum: 600. If the timeout expires the
  background process exits with code 2 and logs `ACTION=pair-timeout`.
  Only valid with `--background`.

The command blocks until the dispatcher approves or denies the request,
or until the connection times out. On approval, the signed certificate
and CA certificate are written to the config directory and the agent is
ready to serve.

If the connection fails with a configuration error, check that the
dispatcher host is reachable, that `pairing-mode` is active on the
dispatcher, and that the correct address was specified.

---

### Orchestrated pairing

For automated provisioning workflows where interactive approval is not
possible, `--background` separates the pairing request submission from the
approval wait. The foreground process exits as soon as the dispatcher
acknowledges the request, printing the request ID to stdout. A background
process holds the connection open and writes the certificate when approval
arrives.

The orchestrator's responsibility is to capture the request ID and call
`ced approve` on the dispatcher host before the timeout expires.

#### Flow

On the agent host (as part of a provisioning script):

```bash
# Start pairing-mode on the dispatcher first, then:
REQID=$(ctrl-exec-agent request-pairing --dispatcher ctrl-exec.example.com \
    --background --timeout 60)
echo "Request ID: $REQID"
```

The command exits 0 immediately, printing the request ID. The background
process is now waiting for approval.

On the dispatcher host (or via the orchestrator calling it remotely):

```bash
ced approve "$REQID"
```

The background process receives the certificate, writes it to
`/etc/ctrl-exec-agent/`, logs `ACTION=pair-complete`, and exits 0.

Confirm pairing succeeded on the agent host:

```bash
ctrl-exec-agent pairing-status
# Exits 0 if paired, 1 if not yet paired
```

#### Exit codes (background process)

`0`
: Approval received and certificates stored successfully.

`2`
: Timeout expired before approval arrived. Key and CSR have been
  cleaned up. Re-run `request-pairing` to try again.

`3`
: Request was explicitly denied by the operator.

#### Timing

The background process holds the connection open for up to `--timeout`
seconds (default 30, maximum 600). The dispatcher's own polling window is
600 seconds — approval must arrive within whichever is shorter. For
orchestrated workflows where the approval step may take time, increase
`--timeout` accordingly:

```bash
REQID=$(ctrl-exec-agent request-pairing --dispatcher ctrl-exec.example.com \
    --background --timeout 120)
```

#### Notes

The background process inherits the connection socket from the foreground
process — no reconnection occurs. The maximum `--timeout` of 600 seconds
is enforced because the dispatcher closes the connection after its own
600-second polling window, making longer waits unreliable.

The request ID printed to stdout is the same ID shown by
`ced list-requests` on the dispatcher host. Both the confirmation
code and the request ID are available via `list-requests` for verification
before approving.

---

### pairing-status

Report whether the agent is paired and show the certificate expiry date.

```bash
ctrl-exec-agent pairing-status
```

Exits 0 if paired, 1 if not paired. Suitable for use in scripts and
health checks.

---

### Auth hook (agent-side)

When `auth_hook` is configured in `agent.conf`, the hook is executed after
every `run` request passes allowlist validation, before the script is
spawned. It provides an independent authorisation layer separate from the
dispatcher's own hook.

#### Context fields

The hook receives a JSON object on stdin:

```json
{
  "action":     "run",
  "script":     "backup-db",
  "args":       ["--full"],
  "username":   "alice",
  "token":      "eyJ...",
  "source_ip":  "10.0.0.5",
  "timestamp":  "2025-01-15T12:00:00Z"
}
```

`action` is always `"run"` on the agent side. The agent does not call the
hook for `ping` requests - those are handled before the hook path is reached.

#### Environment variables

The same context is available as environment variables:

`ENVEXEC_ACTION`
: Always `run` on the agent.

`ENVEXEC_SCRIPT`
: The script name from the allowlist.

`ENVEXEC_ARGS`
: Space-joined argument string. Deprecated - lossy if arguments contain
  spaces. Prefer `ENVEXEC_ARGS_JSON`.

`ENVEXEC_ARGS_JSON`
: JSON array of arguments. Reliable for all argument values.

`ENVEXEC_USERNAME`
: Username passed by the dispatcher in the request body.

`ENVEXEC_TOKEN`
: Token passed by the dispatcher in the request body.

`ENVEXEC_SOURCE_IP`
: IP address of the dispatcher connection.

`ENVEXEC_DISPATCHER`
: Stable identity of the calling dispatcher, resolved from its cert serial via
  the agent's trusted-dispatcher map. Author per-dispatcher policy against this
  value, never the serial - serials rotate, the identity does not. Empty when no
  dispatcher could be resolved.

`ENVEXEC_DISPATCHER_SERIAL`
: The calling dispatcher's certificate serial (hex).

`ENVEXEC_TIMESTAMP`
: ISO 8601 UTC timestamp when the hook was invoked.

#### Exit codes

`0`
: Authorised. Script execution proceeds.

`1`
: Denied - generic refusal. Logged as `reason=denied`.

`2`
: Bad credentials - token not recognised or expired. Logged as
  `reason=bad credentials`.

`3`
: Insufficient privilege - credentials valid but not permitted for this
  script or action. Logged as `reason=insufficient privilege`.

Any other non-zero exit code is treated as denied with reason `hook exited N`.

#### Differences from the dispatcher-side hook

The dispatcher-side hook (configured in `ctrl-exec.conf`) runs on the
dispatcher host before dispatch and covers both `run` and `ping` actions
across all target hosts. The agent-side hook runs on each managed host
independently, covering only `run` requests for that agent.

A request passes both hooks before any script is executed. The hooks are
independent - there is no shared state between them.

The agent hook does not receive a `hosts` field; the agent is unaware of
which other hosts are targeted in the same dispatcher invocation.

If no hook is configured on the agent, the request is authorised
unconditionally at the agent level. The agent relies on mTLS and the
allowlist as its primary access controls; the hook is for supplementary
policy enforcement such as token validation or time-of-day restrictions.

---

### self-check

Validate the local configuration, allowlist, and certificates without
making any network connections. Reports each check individually.

```bash
ctrl-exec-agent self-check
```

Checks performed:

- `agent.conf` parses without error and required keys are present
- `scripts.conf` allowlist loads and all listed scripts are executable
- Pairing certificates are present and not expired
- If `script_dirs` is configured, all scripts in `scripts.conf` fall under
  one of the permitted directories
- If `revoked_serials` is configured, the file is readable and all entries
  are valid serial formats

Exit code is 0 if all checks pass. Use this after installation or
configuration changes to confirm the agent will start cleanly.

---

### self-ping

Perform a live mTLS loopback test against the running agent. Connects to
`127.0.0.1:7443` using the agent's own certificate, verifies the port is
listening, completes the mTLS handshake, and sends a `/ping` request.

```bash
ctrl-exec-agent self-ping
```

The agent will reject the connection with a 403 serial mismatch — the
agent's cert is not a dispatcher cert and the connecting cert serial is
not in the agent's trusted-dispatcher map. This is the expected and
correct result. `self-ping`
treats a 403 response as a pass: it confirms that the port is listening,
the TLS stack is functioning, and the agent is correctly enforcing serial
policy.

Typical output:

```
Checking config...
  Config OK (port 7443)
  Paired: yes (cert expires Jun 18 11:09:58 2028 GMT)
Connecting to 127.0.0.1:7443...
  Port 7443: listening
  mTLS handshake: OK
  Ping response: 403 serial mismatch (expected - agent is running and enforcing policy)
Self-ping complete.
```

Contrast with `self-check`: that mode validates configuration, allowlist,
and cert files locally with no network connection. `self-ping` requires
the agent to be running and paired and exercises the live network path.

Use `self-ping` after installation to confirm the agent is reachable and
policy enforcement is active before the dispatcher attempts its first
connection.

---

## ctrl-exec-api

The `ctrl-exec-api` binary exposes the dispatcher's run, ping, and
discovery operations as an HTTP REST API. It is installed as a systemd
service (`ctrl-exec-api.service`) and listens on `api_port` (default 7445).

Start manually for testing:

```bash
ctrl-exec-api --config /etc/ctrl-exec/ctrl-exec.conf
```

TLS is enabled if `api_cert` and `api_key` are set in `ctrl-exec.conf`
and the files exist. Plain HTTP is used otherwise.

Full endpoint documentation is in API.md. Summary:

`GET /`
: Returns a JSON index of all endpoints and spec URLs. Auth applies as for all endpoints.

`GET /health`
: Returns `{ ok: true, version: "..." }`. Use for liveness checks.

`POST /ping`
: Body: `{ hosts, username?, token? }`. Pings all specified hosts in parallel.

`POST /run`
: Body: `{ hosts, script, args?, username?, token? }`. Runs an allowlisted
  script on all specified hosts. Returns results including a top-level
  `reqid` for status polling and syslog correlation.

`GET /discovery` or `POST /discovery`
: Returns registered agents and their allowlisted scripts. Optional body:
  `{ hosts?, username?, token? }`.

`GET /status/{reqid}`
: Returns the stored result for a completed run. Results are retained for
  24 hours. Returns 404 if the reqid is unknown or has expired.

`GET /openapi.json`
: Serves the static OpenAPI 3.1 spec as installed.

`GET /openapi-live.json`
: Generates and serves a dynamic spec augmented with live host and script
  enumerations from the registry and a capabilities scan.

HTTP status codes: 200 success, 400 bad request, 403 auth denied, 404 not
found / unknown agent (a target host is not a registered agent), 409 lock
conflict, 500 server error.

---

## Syslog

Both binaries log structured key=value records to syslog under the
`daemon` facility. The dispatcher logs under the tag `ctrl-exec-dispatcher`, the
API server under `ctrl-exec-api`, and the agent under `ctrl-exec-agent`. Scripts themselves
may log under any tag they choose.

All log entries use the `ACTION=<name>` field to identify the event type.
The full action catalogue — fields, priorities, example lines, and
alerting guidance — is in LOGGING.md.

Key quick-reference patterns for common operations:

```
ACTION=run EXIT=<n> SCRIPT=<name> TARGET=<host:port> RTT=<ms> REQID=<id>   (ctrl-exec-dispatcher)
ACTION=run EXIT=<n> SCRIPT=<name> PEER=<ip> REQID=<id>                      (agent)
ACTION=ping STATUS=ok|error PEER=<ip> REQID=<id> RTT=<ms>
ACTION=revoked-cert PEER=<ip> SERIAL=<hex>
ACTION=serial-reject PEER=<ip> REQID=<id>
ACTION=rate-block PEER=<ip> REASON=volume|probe
ACTION=ip-block PEER=<ip>
```

To correlate a dispatcher log entry with agent log entries, filter both
sides by `REQID`:

```bash
grep 'REQID=a1b2c3d4' /var/log/syslog
```

See LOGGING.md for the complete action reference, field glossary, and
alert pattern tables.

---

## Managing long-running processes

When a script is expected to run longer than `read_timeout`, the dispatcher
will report a timeout and return a non-zero exit, but the script continues
running on the agent. There is no mechanism to cancel it remotely.

To run a long-lived process and retrieve its output later:

- Have the script start the process in the background (e.g. with `nohup` or
  `systemd-run`) and return immediately with a job identifier or PID written
  to a known path.
- Use a second allowlisted script to poll status or retrieve output by
  reading that path.
- Raise `read_timeout` in `ctrl-exec.conf` if the script must complete
  within a single dispatcher invocation and the runtime is known and bounded.

The agent logs `ACTION=run` only when the script process exits. If the
dispatcher times out before the script completes, no `ACTION=run` entry
appears in the agent's syslog until the script eventually exits. An operator
cannot determine from syslog alone that a script is currently running —
only that it was started (from the dispatcher-side `ACTION=run` entry) and
has not yet completed.

---

## Getting started with examples

The ctrl-exec-demonstrator script exercises all core ctrl-exec
capabilities from a single agent-side script: stdout and stderr capture,
exit code propagation, argument passing, JSON context logging, and
agent-side information. It is installed on every agent host by the
installer and is disabled in `scripts.conf` by default.

To enable it, uncomment the entry in `/etc/ctrl-exec-agent/scripts.conf`
on the agent host and reload the allowlist:

```bash
# On systemd hosts (preferred)
systemctl reload ctrl-exec-agent

# On systems without systemd
kill -HUP $(pidof ctrl-exec-agent)
```

Then run the script directly on the agent host to see all available
subcommands and the exact ced invocations that exercise them:

```bash
/opt/ctrl-exec-scripts/ctrl-exec-demonstrator.sh
```
