package Exec::Lock;

use strict;
use warnings;
use feature      qw(signatures);
no warnings      qw(experimental::signatures);
use Fcntl  qw(LOCK_EX LOCK_NB LOCK_UN);
use File::Path qw(make_path);
use Carp   qw(croak);

use Exec::Log qw();
use Exec::FileUtil qw(flock_path_nb sweep_lock_files);


my $LOCK_DIR = '/var/lib/ctrl-exec/locks';

# Check whether all host:script pairs are available to lock.
# Does NOT acquire locks - only tests availability.
# Use this before forking so the parent can reject early.
#
# Required opts:
#   hosts  => \@hosts
#   script => $name
#
# Optional opts:
#   lock_dir => $path   (default /var/lib/ctrl-exec/locks)
#
# Returns:
#   { ok => 1 }
#   { ok => 0, conflicts => \@locked_pairs }
sub check_available (%opts) {
    my $hosts   = $opts{hosts}   or croak "hosts required";
    my $script  = $opts{script}  or croak "script required";
    my $dir     = $opts{lock_dir} // $LOCK_DIR;

    croak "hosts must be an arrayref" unless ref $hosts eq 'ARRAY';

    _ensure_dir($dir);

    my @conflicts;

    for my $host (@$hosts) {
        my $path = _lock_path($dir, $host, $script);
        my ($fh, $got) = _lock_file($path);

        # Non-blocking attempt - if we can't get it, it's held
        unless ($got) {
            push @conflicts, "$host:$script";
        }
        # We don't hold the lock - release immediately
        flock $fh, LOCK_UN;
        close $fh;
    }

    return @conflicts
        ? { ok => 0, conflicts => \@conflicts }
        : { ok => 1 };
}

# Acquire locks for all host:script pairs.
# Call this in the child process after forking, once check_available has
# confirmed all pairs are free in the parent.
#
# There is a small TOCTOU window between check_available and acquire - if
# another request sneaks in between, acquire will detect the conflict and
# return it. The caller should treat this as a lock error.
#
# Required opts:
#   hosts    => \@hosts
#   script   => $name
#
# Optional opts:
#   lock_dir => $path
#
# Returns:
#   { ok => 1,  handles => \@fh_list }   - locks held; keep handles in scope
#   { ok => 0,  conflicts => \@pairs }   - could not acquire all locks
sub acquire (%opts) {
    my $hosts   = $opts{hosts}   or croak "hosts required";
    my $script  = $opts{script}  or croak "script required";
    my $dir     = $opts{lock_dir} // $LOCK_DIR;

    croak "hosts must be an arrayref" unless ref $hosts eq 'ARRAY';

    _ensure_dir($dir);

    # Opportunistic sweep so lock files for hosts/scripts no longer in use do not
    # accumulate (release never unlinks - see sweep_stale).
    sweep_stale(lock_dir => $dir);

    my @handles;
    my @conflicts;

    for my $host (@$hosts) {
        my $path = _lock_path($dir, $host, $script);
        my ($fh, $got) = _lock_file($path);

        if ($got) {
            push @handles, $fh;
            Exec::Log::log_action('INFO', {
                ACTION => 'lock-acquire',
                HOST   => $host,
                SCRIPT => $script,
            });
        }
        else {
            push @conflicts, "$host:$script";
        }
    }

    if (@conflicts) {
        # Release any we did acquire before failing
        for my $fh (@handles) {
            flock $fh, LOCK_UN;
            close $fh;
        }
        Exec::Log::log_action('WARNING', {
            ACTION    => 'lock-conflict',
            CONFLICTS => join(',', @conflicts),
        });
        return { ok => 0, conflicts => \@conflicts };
    }

    return { ok => 1, handles => \@handles };
}

# Release all locks acquired by acquire().
# Closing the filehandles releases the flocks automatically, but this
# function makes the intent explicit and logs the release.
#
# Required opts:
#   handles => \@fh_list   (from acquire result)
#   hosts   => \@hosts     (for logging only)
#   script  => $name       (for logging only)
sub release (%opts) {
    my $handles = $opts{handles} or croak "handles required";
    my $hosts   = $opts{hosts}   // [];
    my $script  = $opts{script}  // '';

    croak "handles must be an arrayref" unless ref $handles eq 'ARRAY';

    for my $fh (@$handles) {
        flock $fh, LOCK_UN;
        close $fh;
    }

    Exec::Log::log_action('INFO', {
        ACTION => 'lock-release',
        HOSTS  => join(',', @$hosts),
        SCRIPT => $script,
    }) if @$hosts;
}

# Return list of currently held locks by probing each lock file.
# A file that cannot be acquired non-blocking is held by another process.
# Stale lock files (lockable or absent process) are silently skipped.
#
# Optional opts:
#   lock_dir => $path   (default /var/lib/ctrl-exec/locks)
#
# Returns arrayref of hashrefs: { host => $str, script => $str }
# sorted by host:script.
sub list_held (%opts) {
    my $dir = $opts{lock_dir} // $LOCK_DIR;

    return [] unless -d $dir;

    my @held;
    opendir my $dh, $dir or croak "Cannot open lock dir '$dir': $!";
    while (my $f = readdir $dh) {
        next unless $f =~ /^(.+)--(.+)\.lock$/;
        my ($host, $script) = ($1, $2);
        my $path = "$dir/$f";
        my ($fh, $got) = flock_path_nb($path);
        next unless $fh;   # unreadable or a symlink: not a lock we own
        push @held, { host => $host, script => $script } unless $got;
        flock $fh, LOCK_UN;
        close $fh;
    }
    closedir $dh;

    return [ sort { "$a->{host}:$a->{script}" cmp "$b->{host}:$b->{script}" } @held ];
}

# Remove lock files nobody holds, so they do not accumulate for hosts/scripts no
# longer in use. Release deliberately does NOT unlink: a holder that unlinked on
# release could race a locker that had already opened the old inode, leaving two
# processes each holding "the" lock on different inodes. Instead the sweep only
# unlinks a file while holding its flock, and lockers re-check the path after
# locking (Exec::FileUtil::flock_path_nb), so a swept file is simply re-created.
# Run opportunistically from acquire(); returns the number removed.
sub sweep_stale (%opts) {
    my $dir = $opts{lock_dir} // $LOCK_DIR;
    return 0 unless -d $dir;
    return sweep_lock_files($dir, qr/^.+--.+\.lock\z/);
}

# --- private ---

sub _lock_path ($dir, $host, $script) {
    # Sanitise host and script for use in filename
    # Replace anything that isn't alphanumeric, hyphen, or dot with _
    (my $safe_host   = $host)   =~ s/[^\w.\-]/_/g;
    (my $safe_script = $script) =~ s/[^\w.\-]/_/g;
    return "$dir/${safe_host}--${safe_script}.lock";
}

# Open and try to flock one lock file. Returns ($fh, $got): $got is 1 when we now
# hold the lock. Dies with a clear message if the file cannot be opened, in
# particular when the path is a symlink (opened with O_NOFOLLOW, never followed).
sub _lock_file ($path) {
    my ($fh, $got) = flock_path_nb($path);
    return ($fh, $got) if $fh;
    croak "Refusing lock file '$path': it is a symlink"
        if $!{ELOOP};
    croak "Cannot open lock file '$path': $!";
}

sub _ensure_dir ($dir) {
    make_path($dir) unless -d $dir;
}

1;
