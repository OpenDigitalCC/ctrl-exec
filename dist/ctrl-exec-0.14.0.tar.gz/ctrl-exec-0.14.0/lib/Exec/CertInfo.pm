package Exec::CertInfo;

# Shared cert inspection. The "openssl x509 -noout -enddate -> notAfter" parse was
# reimplemented in four modules with subtly different quoting (one interpolated
# the temp path unquoted). Consolidated here so the shell-quoting and parse live
# in one place. This module is also the single home for serial canonicalisation
# (serial_to_hex) - the trust key behind every dispatcher-trusted/serial-revoked
# decision. serial_to_hex is intentionally NOT in @EXPORT_OK: every caller uses
# the fully-qualified name, matching the project's no-default-exports convention.

use strict;
use warnings;
use feature      qw(signatures);
no warnings      qw(experimental::signatures);
use File::Temp qw(tempfile);
use Exporter   qw(import);

our @EXPORT_OK = qw(expiry_from_path expiry_from_pem);

# Return the cert's notAfter date string (openssl form, e.g. "Jun  7 16:28:00
# 2028 GMT"), or undef if the file is unreadable / not a cert.
sub expiry_from_path ($path) {
    my $out = `openssl x509 -noout -enddate -in \Q$path\E 2>/dev/null`;
    return unless defined $out && $out =~ /notAfter=(.+)/;
    (my $date = $1) =~ s/\s+\z//;
    return $date;
}

# As expiry_from_path, but for a cert held in a PEM string (written to a private
# temp file first).
sub expiry_from_pem ($pem) {
    my ($fh, $path) = tempfile(SUFFIX => '.crt', UNLINK => 1);
    print $fh $pem;
    close $fh;
    return expiry_from_path($path);
}

# Return the cert's serial as canonical lowercase hex (via serial_to_hex), or
# undef if the file is unreadable or carries no serial. The single reader the
# dispatcher's approve and rotate paths share - the twin of expiry_from_path,
# so the openssl shell-quoting and the serial-regex live in one place. A drift
# between two copies here causes a permanent "serial mismatch" rejection.
sub serial_from_path ($path) {
    my $out = `openssl x509 -noout -serial -in \Q$path\E 2>/dev/null`;
    return unless defined $out && $out =~ /serial=([0-9A-Fa-f]+)/;
    return serial_to_hex($1);
}

# Return the SHA-256 fingerprint of the cert (the digest of its DER encoding) as
# 64 lowercase hex characters, or undef if the file is unreadable or not a cert.
# For a file holding a chain this is the first cert, which is the one a TLS
# server loaded from it presents. The dispatcher binds the v2 pairing code to
# this value; the agent computes the same digest from the certificate it saw on
# the pairing connection (Exec::Agent::AgentPairing::submit_pairing_request).
sub fingerprint_from_path ($path) {
    my $out = `openssl x509 -noout -fingerprint -sha256 -in \Q$path\E 2>/dev/null`;
    return unless defined $out && $out =~ /=\s*((?:[0-9A-Fa-f]{2}:){31}[0-9A-Fa-f]{2})\s*$/m;
    (my $hex = lc $1) =~ s/://g;
    return $hex;
}

# As fingerprint_from_path, for a certificate held in a PEM string.
sub fingerprint_from_pem ($pem) {
    my $path = _pem_tempfile($pem);
    return fingerprint_from_path($path);
}

# The subject of a certificate held in a PEM string, in RFC 2253 form
# ("CN=ctrl-exec CA d1 1a2b3c4d"), or undef.
sub subject_from_pem ($pem) {
    my $path = _pem_tempfile($pem);
    my $out = `openssl x509 -noout -subject -nameopt RFC2253 -in \Q$path\E 2>/dev/null`;
    return unless defined $out && $out =~ /^subject=\s*(.*?)\s*$/m;
    return $1;
}

# The public key (PEM) of a certificate ('x509') or a certificate request
# ('req') held in a PEM string, or undef. Two values are compared to tell
# whether a certificate and a CSR carry the same key.
sub public_key_from_pem ($pem, $kind = 'x509') {
    my $path = _pem_tempfile($pem);
    my $cmd  = $kind eq 'req' ? 'req' : 'x509';
    my $out = `openssl $cmd -noout -pubkey -in \Q$path\E 2>/dev/null`;
    return unless $? == 0 && defined $out && $out =~ /-----BEGIN PUBLIC KEY-----/;
    return $out;
}

# Whether the certificate $leaf_pem was issued by the CA certificate $ca_pem,
# with that CA as the only trust anchor (nothing from a system store): full
# X.509 verification - signature, validity dates, the CA's constraints.
# Returns undef when it verifies, or the reason it does not.
sub verify_issued_by ($leaf_pem, $ca_pem) {
    require IO::Socket::SSL;   # loads and initialises Net::SSLeay
    my ($leaf, $ca) = map { _x509($_) } $leaf_pem, $ca_pem;
    unless ($leaf && $ca) {
        Net::SSLeay::X509_free($_) for grep { $_ } $leaf, $ca;
        return 'not a readable certificate';
    }
    my $store = Net::SSLeay::X509_STORE_new();
    my $ctx   = Net::SSLeay::X509_STORE_CTX_new();
    my ($ok, $err);
    Net::SSLeay::X509_STORE_add_cert($store, $ca);
    Net::SSLeay::X509_STORE_set_flags($store, Net::SSLeay::X509_V_FLAG_PARTIAL_CHAIN());
    if (store_ctx_init($ctx, $store, $leaf)) {
        $ok  = Net::SSLeay::X509_verify_cert($ctx) == 1;
        $err = Net::SSLeay::X509_verify_cert_error_string(
            Net::SSLeay::X509_STORE_CTX_get_error($ctx));
    }
    Net::SSLeay::X509_STORE_CTX_free($ctx);
    Net::SSLeay::X509_STORE_free($store);
    Net::SSLeay::X509_free($_) for $leaf, $ca;
    Net::SSLeay::ERR_clear_error();
    return if $ok;
    return $err // 'verification could not run';
}

# Certificate roles (T-066). From 0.14 the dispatcher CA marks every certificate
# it issues with what it is - 'dispatcher' (setup-ctrl-exec, rotation) or
# 'agent' (pairing approval, renewal) - in a non-critical private extension:
# OID $ROLE_OID, value a DER UTF8String. The CA sets it from the code path that
# signs, never from a CSR. Agents are TLS servers on 7443 and dispatchers
# clients there, the reverse on the pairing port, so serverAuth/clientAuth
# extended key usage cannot tell the two apart; the role extension can.
#
# The OID is self-assigned under the UUID arc 2.25 (ITU-T X.667: 2.25 then the
# UUID as one integer), from the random UUID c872e709-8aa2-4a48-afee-39735113c65a,
# because the project holds no private enterprise number. It means "ctrl-exec
# certificate role" and nothing else; never reuse it for another purpose.
our $ROLE_OID = '2.25.266442206991433179228746487034237142618';

# The role a certificate held in a PEM string is marked with: 'dispatcher',
# 'agent', 'unknown' (the role extension is there but its value is neither,
# or unreadable), or undef when it carries no role extension - every
# certificate issued before 0.14, until its next renewal or rotation - or is
# not a readable certificate.
sub cert_role ($pem) {
    require IO::Socket::SSL;   # loads and initialises Net::SSLeay
    my $x509 = _x509($pem) or return;
    my $role = x509_role($x509);
    Net::SSLeay::X509_free($x509);
    return $role;
}

# As cert_role, for a Net::SSLeay X509 handle (e.g. IO::Socket::SSL's
# peer_certificate), which is not freed. When more than one role extension is
# present (the CA never writes two) an 'agent' mark wins, then 'unknown'.
sub x509_role ($x509) {
    my %seen;
    my $n = Net::SSLeay::X509_get_ext_count($x509) // 0;
    for my $i (0 .. $n - 1) {
        my $ext = Net::SSLeay::X509_get_ext($x509, $i) or next;
        my $oid = Net::SSLeay::OBJ_obj2txt(Net::SSLeay::X509_EXTENSION_get_object($ext), 1);
        next unless defined $oid && $oid eq $ROLE_OID;
        my $der = Net::SSLeay::P_ASN1_STRING_get(Net::SSLeay::X509_EXTENSION_get_data($ext)) // '';
        # UTF8String: tag 0x0c, a short-form length, the value.
        my ($tag, $len) = unpack 'C C', $der;
        my $val = defined $len && $tag == 0x0c && $len < 0x80 && length($der) == $len + 2
                ? substr($der, 2) : '';
        $seen{ $val eq 'agent' || $val eq 'dispatcher' ? $val : 'unknown' } = 1;
    }
    Net::SSLeay::ERR_clear_error();
    for my $role (qw(agent unknown dispatcher)) {
        return $role if $seen{$role};
    }
    return;
}

# Authority Key Identifier (T-068). Every certificate Exec::CA issues from 0.14
# carries one; one issued before 0.14 on an OpenSSL 1.1 host has none. Without
# it OpenSSL picks the issuer of a certificate by name alone, so when a trust
# store holds two CAs with one name (every dispatcher CA made before 0.14 is
# called "ctrl-exec CA") the certificate is checked against the first of them
# and refused when the other issued it.
my $AKI_OID = '2.5.29.35';

# 1 when the certificate (a Net::SSLeay X509 handle, not freed) carries an
# Authority Key Identifier, else 0.
sub x509_has_aki ($x509) {
    my $n = Net::SSLeay::X509_get_ext_count($x509) // 0;
    for my $i (0 .. $n - 1) {
        my $ext = Net::SSLeay::X509_get_ext($x509, $i) or next;
        my $oid = Net::SSLeay::OBJ_obj2txt(Net::SSLeay::X509_EXTENSION_get_object($ext), 1);
        return 1 if defined $oid && $oid eq $AKI_OID;
    }
    return 0;
}

# As x509_has_aki, for the first certificate in the file at $path: 1, 0, or
# undef when the file is unreadable or holds no certificate.
sub has_aki_path ($path) {
    require IO::Socket::SSL;   # loads and initialises Net::SSLeay
    return unless defined $path && -r $path;
    open my $fh, '<', $path or return;
    my $pem = do { local $/; <$fh> };
    close $fh;
    my $x509 = _x509($pem) or do { Net::SSLeay::ERR_clear_error(); return };
    my $has  = x509_has_aki($x509);
    Net::SSLeay::X509_free($x509);
    return $has;
}

# Net::SSLeay::X509_STORE_CTX_init, true when the context was initialised.
# Net::SSLeay before 1.92 (1.88 in Debian 11, with OpenSSL 1.1) returns nothing
# from it although the context is initialised; testing that empty return as
# failure meant verification never ran there and every check refused. No
# return value is taken as initialised: should it not be, X509_verify_cert
# fails, so the check still fails closed.
sub store_ctx_init ($ctx, $store, $x509, $chain = undef) {
    my @r = defined $chain
        ? Net::SSLeay::X509_STORE_CTX_init($ctx, $store, $x509, $chain)
        : Net::SSLeay::X509_STORE_CTX_init($ctx, $store, $x509);
    return 1 unless @r && defined $r[0];
    return $r[0] ? 1 : 0;
}

sub _x509 ($pem) {
    my $bio = Net::SSLeay::BIO_new(Net::SSLeay::BIO_s_mem()) or return;
    Net::SSLeay::BIO_write($bio, $pem // '');
    my $x509 = Net::SSLeay::PEM_read_bio_X509($bio);
    Net::SSLeay::BIO_free($bio);
    return $x509 || undef;
}

# A private temp file holding $pem (removed at exit), for the openssl CLI.
sub _pem_tempfile ($pem) {
    my ($fh, $path) = tempfile(SUFFIX => '.pem', UNLINK => 1);
    print $fh $pem // '';
    close $fh;
    return $path;
}

# Parse a SHA-256 certificate fingerprint as an operator types or pastes it:
# "SHA256:" then 64 hex digits, with or without colons between the bytes, in
# either case. The prefix may be left off, so the colon form openssl prints
# (`openssl x509 -fingerprint -sha256`) is accepted as it stands once the
# "sha256 Fingerprint=" label is dropped. Returns 64 lowercase hex characters,
# or undef for anything else (a SHA-1 length, a stray character, an empty value).
sub parse_sha256_fingerprint ($str) {
    return unless defined $str;
    (my $s = $str) =~ s/^\s+|\s+$//g;
    $s =~ s/\ASHA-?256://i;
    return unless $s =~ /\A(?:[0-9A-Fa-f]{64}|(?:[0-9A-Fa-f]{2}:){31}[0-9A-Fa-f]{2})\z/;
    $s =~ s/://g;
    return lc $s;
}

# The display form of a SHA-256 fingerprint (64 hex characters): "SHA256:"
# then lowercase hex without colons, the form the pairing-mode banner and
# 'ctrl-exec-dispatcher ca-fingerprint' print and request-pairing accepts.
sub format_sha256_fingerprint ($hex) {
    return 'SHA256:' . lc $hex;
}

# Parse an openssl notAfter string ("Mon DD HH:MM:SS YYYY GMT", as produced by
# expiry_from_path) to a Unix epoch (UTC), or undef if it cannot be parsed. The
# single notAfter->epoch parser: the renewal-due check (Engine) and the
# days-remaining check (Rotation) previously parsed this string two different
# ways (Time::Piece strptime vs a manual timegm) that could disagree on the same
# cert. timegm because the date is UTC; an explicit month map because strptime
# '%b' is locale-sensitive.
sub expiry_epoch ($date_str = undef) {
    return unless defined $date_str;
    my %months = qw(Jan 0 Feb 1 Mar 2 Apr 3 May 4 Jun 5
                    Jul 6 Aug 7 Sep 8 Oct 9 Nov 10 Dec 11);
    return unless $date_str =~ /(\w+)\s+(\d+)\s+(\d+):(\d+):(\d+)\s+(\d{4})\s+GMT/;
    my ($mon, $day, $h, $m, $s, $yr) = ($1, $2, $3, $4, $5, $6);
    return unless exists $months{$mon};
    require Time::Local;
    return Time::Local::timegm($s, $m, $h, $day, $months{$mon}, $yr - 1900);
}

# Normalise a serial number to lowercase hex.
# Accepts either a decimal string (from IO::Socket::SSL peer_certificate)
# or a hex string (from openssl x509 -serial output).
# Hex strings are identified by non-decimal characters or a leading 0x.
sub serial_to_hex ($serial) {
    return '' unless defined $serial && length $serial;
    $serial =~ s/^0x//i;
    $serial =~ s/^serial=//i;

    # Strip colon separators (e.g. DE:AD:BE:EF from IO::Socket::SSL or a serial
    # pasted from `openssl x509 -text`). A colon form is always hex bytes, so it
    # must use the SAME leading-zero strip as the plain-hex branch below - not a
    # byte-pair strip, which diverges for any serial whose top byte is 0x01-0x0f
    # (e.g. "00:0a" -> "0a" but the live plain-hex "0a" -> "a", a silent
    # trust-key mismatch). One strip, one canonical form.
    if ($serial =~ /:/) {
        $serial =~ s/://g;
        $serial = lc $serial;
        $serial =~ s/\A0+(?=[0-9a-f])//;
        return $serial;
    }

    $serial = lc $serial;

    # A pure decimal string must be converted. Test explicitly: decimal strings
    # contain only [0-9] and cannot contain [a-f], but digits-only strings also
    # satisfy \A[0-9a-f]+\z so we must check for decimal first.
    if ($serial =~ /\A[0-9]+\z/) {
        # Cert serials can be up to 20 bytes (160 bits), requiring bignum
        # arithmetic. We do not use sprintf '%x' because Perl's native integer
        # coercion silently loses precision for large decimal strings.
        require Math::BigInt;
        return lc( Math::BigInt->new($serial)->as_hex =~ s/^0x//r );
    }

    # If it contains only valid hex characters it is already hex. Strip any
    # insignificant leading zeros first so a value carrying a leading 00 byte -
    # a serial migrated from an older single-serial file, or a hand-edited map
    # entry - canonicalises to the same key the live readers produce. Both
    # `openssl x509 -serial` and Net::SSLeay::P_ASN1_INTEGER_get_hex emit minimal
    # hex with no leading zero, so without this strip '00aabb...' (stored) never
    # matches a live 'aabb...' and every request from that dispatcher is rejected
    # as a serial mismatch. (The colon-separated branch above strips leading
    # zeros the same way, so both branches yield one canonical form.)
    if ($serial =~ /\A[0-9a-f]+\z/) {
        $serial =~ s/\A0+(?=[0-9a-f])//;
        return $serial;
    }

    # Contains non-hex characters - treat as large decimal via bignum.
    require Math::BigInt;
    return lc( Math::BigInt->new($serial)->as_hex =~ s/^0x//r );
}

1;
