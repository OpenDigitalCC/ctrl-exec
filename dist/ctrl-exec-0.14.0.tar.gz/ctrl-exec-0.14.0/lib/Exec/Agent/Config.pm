package Exec::Agent::Config;

use strict;
use warnings;
use feature qw(signatures);
no warnings qw(experimental::signatures);
use Carp qw(croak);
use Cwd  qw(abs_path);
use Fcntl qw();
use Exec::Log qw();
use Exec::RateLimit qw();
use Exec::Agent::AgentPairing qw();


# Return the first of the given paths that cannot be read because of a
# permission error (EACCES - the file itself, or a directory on the way to it),
# or undef when none is. Lets a CLI command that was not run as root say so,
# rather than reporting a missing file or a configuration error. A path that
# does not exist (ENOENT) is not a permission problem and is not reported.
sub unreadable_path (@paths) {
    for my $p (@paths) {
        next unless defined $p && length $p;
        if (open my $fh, '<', $p) { close $fh; next; }
        return $p if $!{EACCES};
    }
    return;
}

# Storage limits of the C executor (src/ctrl-exec-executor.c: MAX_PROFILES, MAX_CAPS,
# MAX_WRITABLE, MAX_DIRS, NAMELEN, VALLEN). The executor rejects a config that
# exceeds them rather than truncating a name or path, so this parser rejects the
# same configs - otherwise the front end would authorise a file the executor
# refuses to load. KEEP IN SYNC WITH src/ctrl-exec-executor.c.
use constant {
    MAX_PROFILES => 64,
    MAX_CAPS     => 32,
    MAX_WRITABLE => 32,
    MAX_DIRS     => 32,
    NAMELEN      => 128,    # a value must be shorter than this
    VALLEN       => 4096,   # a path must be shorter than this
};

# Pasted non-ASCII spaces (T-059): U+00A0, U+2000-U+200A (U+2007 among them)
# and U+202F, UTF-8 encoded, each become one ASCII space before a scripts.conf
# or agent.conf line is parsed, so a line copied from a terminal or chat UI
# reads as typed. The files are read as bytes. The executor does the same
# (ascii_spaces in src/ctrl-exec-executor.c; t/exec-conformance.t). Returns
# how many were replaced.
sub _ascii_spaces ($lineref) {
    return $$lineref =~ s/\xC2\xA0|\xE2\x80[\x80-\x8A\xAF]/ /g || 0;
}

# One line per file load that held any: the operator can find and clean the
# file, nothing else changes.
sub _log_ascii_spaces ($path, $lines) {
    return unless $lines;
    Exec::Log::log_action('INFO', {
        ACTION => 'config-nonascii-space',
        FILE   => $path,
        LINES  => $lines,
        REASON => 'non-ASCII spaces (such as U+00A0) read as ordinary spaces',
    });
}

# Load and validate agent.conf
# Returns hashref of config values or dies with error
sub load_config ($path = undef) {
    $path //= '/etc/ctrl-exec-agent/agent.conf';

    open my $fh, '<', $path
        or croak "Cannot open config '$path': $!";

    my %config;
    my $section = '';      # current section name; '' means top-level
    my $cur_profile;       # name of the [profile <name>] currently being read
    my $spaced = 0;        # lines with pasted non-ASCII spaces

    while (my $line = <$fh>) {
        chomp $line;
        # The executor reads lines as C strings; a NUL would hide the rest of
        # the line from it. Refuse rather than let the two parsers see
        # different values.
        croak "Malformed config line in '$path': contains a NUL byte"
            if index($line, "\0") >= 0;
        $spaced++ if _ascii_spaces(\$line);
        next if $line =~ /^\s*#/;   # skip comments
        next if $line =~ /^\s*$/;   # skip blank lines

        # Section header: [name], or [profile <name>] which carries a sub-name.
        if ($line =~ /^\s*\[\s*(\w+)(?:\s+([\w.-]+))?\s*\]\s*$/) {
            my ($sect, $sub) = (lc $1, $2);
            if ($sect eq 'profile') {
                croak "Profile section needs a name ([profile <name>]) in '$path'"
                    unless defined $sub && length $sub;
                croak "Profile name too long in '$path': $sub"
                    if length $sub >= NAMELEN;
                $section     = 'profile';
                $cur_profile = $sub;
                $config{profiles}{$sub} //= {};
                croak "Too many profiles in '$path' (max " . MAX_PROFILES . ")"
                    if keys %{ $config{profiles} } > MAX_PROFILES;
            }
            else {
                $section     = $sect;
                $cur_profile = undef;
            }
            next;
        }

        if ($line =~ /^\s*(\w+[\w-]*)\s*=\s*(.+?)\s*$/) {
            my ($k, $v) = ($1, $2);
            if ($section eq 'tags') {
                $config{tags}{$k} = $v;
            }
            elsif ($section eq 'profile') {
                # Raw value; normalised in _validate_config.
                $config{profiles}{$cur_profile}{$k} = $v;
            }
            elsif ($section eq '') {
                # These names hold the parsed sections below; a plain top-level
                # key of the same name would clobber them (and the executor
                # rejects them too).
                croak "Reserved config key '$k' in '$path'"
                    if $k eq 'profiles' || $k eq 'tags';
                $config{$k} = $v;
            }
            # silently ignore keys in unrecognised sections
        }
        else {
            croak "Malformed config line in '$path': $line";
        }
    }
    close $fh;

    _validate_config(\%config, $path);
    _log_ascii_spaces($path, $spaced);
    return \%config;
}

sub _validate_config ($config, $path) {
    my @required = qw(port cert key ca);
    for my $key (@required) {
        croak "Missing required config key '$key' in '$path'"
            unless exists $config->{$key};
    }
    croak "port must be numeric in '$path'"
        unless $config->{port} =~ /^\d+$/;

    # Parse script_dirs from colon-separated string into arrayref
    if (defined $config->{script_dirs} && length $config->{script_dirs}) {
        $config->{script_dirs} = [
            grep { length $_ } split /:/, $config->{script_dirs}
        ];
        # NB: a value that yields no directories (":::") stays an empty list,
        # which restricts every script out - the executor does the same.
        croak "Too many script_dirs in '$path' (max " . MAX_DIRS . ")"
            if @{ $config->{script_dirs} } > MAX_DIRS;
        for my $d (@{ $config->{script_dirs} }) {
            croak "script_dirs entry too long in '$path'" if length $d >= VALLEN;
        }
    }
    else {
        delete $config->{script_dirs};   # absent = no restriction
    }

    # script_ownership (T-054): what a script that breaks the ownership rule
    # (script_owner_check) does. 'warn' (the default): it stays allowlisted and
    # runs, and the reason is logged at load and shown by self-check. 'strict':
    # it is refused, by the front end and by the executor. Anything else is a
    # config error. KEEP IN SYNC WITH src/ctrl-exec-executor.c parse_agent_conf.
    $config->{script_ownership} //= 'warn';
    croak "Invalid script_ownership '$config->{script_ownership}' in '$path'"
        . " (expected warn or strict)"
        unless $config->{script_ownership} =~ /\A(?:warn|strict)\z/;

    # KEEP IN SYNC WITH src/ctrl-exec-executor.c (set_profile_field / parse_agent_conf).
    # The executor re-derives the same security decision from this same config; if
    # the two parsers diverge, the executor applies a different privilege than this
    # front-end authorised. t/exec-conformance.t gates that they agree.
    #
    # Normalise security profiles ([profile <name>] blocks): caps -> arrayref of
    # CAP_* names, writable -> arrayref of absolute dirs, run_as validated,
    # no_new_privileges -> bool (default on). The executor enforces all of these
    # before exec: caps, run_as, no_new_privileges, and - when `writable` is set -
    # a read-only filesystem with those paths carved out read-write (plus a private
    # /tmp). Every profile must be defined here, including 'default' (the profile
    # an unannotated script resolves to) - there is no implicit built-in. A script
    # whose profile is undefined makes the agent refuse to serve (fail-closed), so
    # nothing ever runs under an unstated - possibly root - context.
    if (ref $config->{profiles} eq 'HASH') {
        for my $pname (sort keys %{ $config->{profiles} }) {
            my $p = $config->{profiles}{$pname};

            $p->{caps} = [ grep { length } split /[,\s]+/, ($p->{caps} // '') ];
            for my $c (@{ $p->{caps} }) {
                next if $c =~ /^CAP_[A-Z0-9_]+$/;
                # A token starting with '#' almost always means the operator put
                # an inline comment after the value - which this format does not
                # support (whole-line comments only). Say so, instead of the bare
                # "invalid capability '#'".
                my $hint = $c =~ /^#/
                    ? " - inline '# ...' comments are not supported on value lines;"
                      . " put the comment on its own line"
                    : '';
                croak "Profile '$pname': invalid capability '$c' (expected CAP_*) "
                    . "in '$path'$hint";
            }
            croak "Profile '$pname': too many caps in '$path' (max " . MAX_CAPS . ")"
                if @{ $p->{caps} } > MAX_CAPS;
            for my $c (@{ $p->{caps} }) {
                croak "Profile '$pname': capability name too long in '$path'"
                    if length $c >= NAMELEN;
            }

            $p->{writable} = [ grep { length } split /:/, ($p->{writable} // '') ];
            for my $w (@{ $p->{writable} }) {
                croak "Profile '$pname': writable path must be absolute: '$w' in '$path'"
                    unless $w =~ m{^/};
                croak "Profile '$pname': writable path too long in '$path'"
                    if length $w >= VALLEN;
            }
            croak "Profile '$pname': too many writable paths in '$path' (max " . MAX_WRITABLE . ")"
                if @{ $p->{writable} } > MAX_WRITABLE;

            if (defined $p->{run_as} && length $p->{run_as}) {
                croak "Profile '$pname': invalid run_as '$p->{run_as}' in '$path'"
                    unless $p->{run_as} =~ /^(?:[A-Za-z_][A-Za-z0-9_-]*|\d+)\z/
                        && length $p->{run_as} < NAMELEN;
                # Bound a numeric uid/gid to 32 bits, matching the C executor
                # (ctrl-exec-executor.c set_profile_field): a value that does not fit
                # uid_t would be rejected by the executor at load, so reject it
                # here too rather than let the two parsers disagree.
                croak "Profile '$pname': run_as '$p->{run_as}' out of range in '$path'"
                    if $p->{run_as} =~ /^\d+$/ && $p->{run_as} > 0xFFFFFFFF;
            }
            else {
                delete $p->{run_as};
            }

            $p->{no_new_privileges} =
                (!defined $p->{no_new_privileges}
                 || $p->{no_new_privileges} =~ /^(?:1|y|yes|true|on)$/i) ? 1 : 0;
        }
    }

    # Parse allowed_ips from comma-separated string into arrayref.
    # Validate CIDR prefix lengths AND the dotted-quad itself at load time,
    # rejecting invalid entries with a warning so ip_allowed only ever sees
    # well-formed, canonical entries. Canonicalising the octets here (stripping
    # leading zeros) is what makes ip_allowed's string-eq match safe: the live
    # peer IP from the socket is canonical, so a zero-padded config entry like
    # "10.00.0.0/16" would otherwise compare "00" ne "0" and silently never
    # match - failing open by omission. We normalise instead, or warn-and-drop.
    if (my $raw = $config->{allowed_ips}) {
        my @candidates = grep { length } map { s/^\s+|\s+$//gr } split /,/, $raw;
        my @entries;
        for my $entry (@candidates) {
            my ($addr, $prefix_len);
            if ($entry =~ m{/}) {
                ($addr, $prefix_len) = split m{/}, $entry, 2;
                unless (defined $prefix_len && $prefix_len =~ /^\d+$/ &&
                        grep { $prefix_len == $_ } (8, 16, 24)) {
                    Exec::Log::log_action('WARNING', {
                        ACTION => 'config-warn',
                        ENTRY  => $entry,
                        MSG    => 'unsupported prefix length',
                    });
                    next;
                }
            }
            else {
                $addr = $entry;
            }
            my $canon_addr = _normalize_ipv4($addr);
            unless (defined $canon_addr) {
                Exec::Log::log_action('WARNING', {
                    ACTION => 'config-warn',
                    ENTRY  => $entry,
                    MSG    => 'malformed IPv4 address',
                });
                next;
            }
            push @entries,
                defined $prefix_len ? "$canon_addr/$prefix_len" : $canon_addr;
        }
        if (@entries) {
            $config->{allowed_ips} = \@entries;
        }
        else {
            delete $config->{allowed_ips};
        }
    }
    else {
        delete $config->{allowed_ips};
    }

    # Parse rate limit configuration.
    # rate_limit_disable = 1  disables rate limiting entirely (testing only).
    # rate_limit_volume  = <limit>/<window>/<block>  e.g. 10/60/300
    # rate_limit_probe   = <limit>/<window>/<block>  e.g. 3/600/3600
    # Absent or invalid values leave defaults in place (current constants).
    {
        my %rl;
        if ($config->{rate_limit_disable} && $config->{rate_limit_disable} =~ /^[1y]/i) {
            $rl{disabled} = 1;
        }
        for my $param (qw(volume probe)) {
            my $key = "rate_limit_$param";
            if (my $raw = $config->{$key}) {
                if (my $t = Exec::RateLimit::parse_limit_spec($raw)) {
                    @rl{"${param}_limit", "${param}_window", "${param}_block"} = @$t;
                }
                else {
                    Exec::Log::log_action('WARNING', {
                        ACTION => 'config-warn',
                        KEY    => $key,
                        MSG    => 'invalid format, expected limit/window/block - using defaults',
                    });
                }
            }
        }
        $config->{rate_limit} = \%rl if %rl;
    }

    # Validate auth_hook if present
    if (defined $config->{auth_hook} && length $config->{auth_hook}) {
        croak "auth_hook '$config->{auth_hook}' is not executable in '$path'"
            unless -f $config->{auth_hook} && -x $config->{auth_hook};
    }
    else {
        delete $config->{auth_hook};   # absent = no hook
    }
}

# The scripts.conf key=value options the agent reads (dispatcher= is read as
# dispatchers=). Any other key is an unknown option: logged once per load
# (log_unknown_options) and shown by self-check; the entry is unaffected.
use constant KNOWN_OPTIONS => { map { $_ => 1 } qw(profile input output dispatchers) };

# Load and parse scripts.conf allowlist
# Returns hashref: { script_name => { path, profile, input, output[, dispatchers] } }
# Dies on parse errors; unknown/bad entries are skipped with a warning
#
# Optional:
#   $script_dirs  arrayref of approved directories; undef = no restriction
#   $ownership    agent.conf script_ownership: 'warn' (default) or 'strict'
sub load_allowlist ($path = undef, $script_dirs = undef, $ownership = 'warn') {
    my ($allowlist) = load_allowlist_full($path, $script_dirs, $ownership);
    return $allowlist;
}

# As load_allowlist, but also returns the entries that were skipped and why:
#   ($allowlist, $skipped) = load_allowlist_full($path, $script_dirs, $ownership)
# $skipped is { script_name => "reason" }, the text a refused run reports as
# "script not permitted: <reason>" (T-044). A line with no usable name (NUL
# byte, malformed) cannot be keyed by name and is only warned about.
#
# A script that breaks the ownership rule (T-045) is skipped when $ownership is
# 'strict'. With 'warn' (T-054, the default) it stays allowlisted and its entry
# carries the reason as ownership_warning, which log_ownership_warnings logs
# and self-check shows.
sub load_allowlist_full ($path = undef, $script_dirs = undef, $ownership = 'warn') {
    $path      //= '/etc/ctrl-exec-agent/scripts.conf';
    $ownership //= 'warn';

    open my $fh, '<', $path
        or croak "Cannot open allowlist '$path': $!";

    my (%allowlist, %skipped);
    my $spaced = 0;        # lines with pasted non-ASCII spaces
    while (my $line = <$fh>) {
        chomp $line;
        if (index($line, "\0") >= 0) {
            warn "Allowlist: skipping line containing a NUL byte\n";
            next;
        }
        $spaced++ if _ascii_spaces(\$line);
        next if $line =~ /^\s*#/;
        next if $line =~ /^\s*$/;
        if ($line =~ /^\s*([\w-]+)\s*=\s*(.+?)\s*$/) {
            my ($name, $rest) = ($1, $2);

            # The value is the absolute script path plus optional, order-
            # independent key=value annotations (profile=, future schema=/
            # timeout=). The lone bare token is the path; key=value tokens are
            # annotations - so 'profile=' may appear before or after the path.
            # 'dispatcher=' (singular) is read as 'dispatchers=' (T-063), so the
            # likeliest typo limits the script instead of leaving it open;
            # across the two spellings the last on the line wins, as for any
            # repeated annotation (the executor does the same). Any other key
            # is kept as an unknown option: logged at load, behaviour unchanged.
            my ($script_path, $extra_path, %annot, %unknown);
            for my $tok (split /\s+/, $rest) {
                if ($tok =~ /^([a-z_]+)=(.*)$/) {
                    my ($k, $v) = ($1, $2);
                    $k = 'dispatchers' if $k eq 'dispatcher';
                    $unknown{$k} = 1 unless KNOWN_OPTIONS->{$k};
                    $annot{$k} = $v;
                }
                elsif (defined $script_path) {
                    $extra_path = $tok;
                }
                else {
                    $script_path = $tok;
                }
            }

            unless (defined $script_path) {
                $skipped{$name} = 'its scripts.conf entry has no script path';
                warn "Allowlist: skipping '$name' - no script path\n";
                next;
            }
            if (defined $extra_path) {
                $skipped{$name} = "its scripts.conf entry has more than one path"
                                . " ('$script_path' and '$extra_path')";
                warn "Allowlist: skipping '$name' - more than one path on the line\n";
                next;
            }
            if (length $script_path >= VALLEN) {
                $skipped{$name} = 'its path is too long (' . length($script_path)
                                . ' characters; the limit is ' . (VALLEN - 1) . ')';
                warn "Allowlist: skipping '$name' - path or profile name too long\n";
                next;
            }
            if (length($annot{profile} // '') >= NAMELEN) {
                $skipped{$name} = 'its profile name is too long (' . length($annot{profile})
                                . ' characters; the limit is ' . (NAMELEN - 1) . ')';
                warn "Allowlist: skipping '$name' - path or profile name too long\n";
                next;
            }
            # input= (T-013): how confidential run input is delivered. Absent
            # means context; anything but the four forms is a skipped script, so
            # a typo cannot silently fall back to a different delivery.
            my $input_mode = 'context';
            if (exists $annot{input}) {
                if (defined(my $why = input_mode_problem($annot{input}))) {
                    $skipped{$name} = $why;
                    warn "Allowlist: skipping '$name' - $why\n";
                    next;
                }
                $input_mode = $annot{input};
            }
            # output= (T-053): confidential output is returned to the caller
            # but never stored (the result is marked output_confidential).
            # Absent means stored; any other value skips the script, so a typo
            # cannot silently leave a secret to be stored.
            my $output_mode = 'stored';
            if (exists $annot{output}) {
                if (defined(my $why = output_mode_problem($annot{output}))) {
                    $skipped{$name} = $why;
                    warn "Allowlist: skipping '$name' - $why\n";
                    next;
                }
                $output_mode = $annot{output};
            }
            # dispatchers= (T-063): the dispatcher ids (from the trusted map)
            # that may run and see the script. Absent means every trusted
            # dispatcher; a bad value skips the script, so a typo never widens
            # it to every dispatcher.
            my $dispatchers;
            if (exists $annot{dispatchers}) {
                if (defined(my $why = dispatchers_problem($annot{dispatchers}))) {
                    $skipped{$name} = $why;
                    warn "Allowlist: skipping '$name' - $why\n";
                    next;
                }
                $dispatchers = [ split /,/, $annot{dispatchers} ];
            }
            unless ($script_path =~ m{^/}) {
                $skipped{$name} = "'$script_path' is not an absolute path";
                warn "Allowlist: skipping '$name' - path must be absolute: $script_path\n";
                next;
            }
            if ($script_dirs && !_path_in_dirs($script_path, $script_dirs)) {
                $skipped{$name} = not_in_dirs_reason($script_path, $script_dirs);
                warn "Allowlist: skipping '$name' - path not in approved script_dirs: $script_path\n";
                next;
            }
            my $owner_why = script_owner_problem($script_path);
            if (defined $owner_why && $ownership eq 'strict') {
                $skipped{$name} = $owner_why;
                warn "Allowlist: skipping '$name' - $owner_why\n";
                next;
            }
            warn "Allowlist: '$name' - $owner_why; running anyway (script_ownership = warn)\n"
                if defined $owner_why;
            $allowlist{$name} = {
                path    => $script_path,
                profile => ($annot{profile} // 'default'),
                input   => $input_mode,
                output  => $output_mode,
                (defined $dispatchers ? (dispatchers => $dispatchers) : ()),
                (%unknown ? (unknown_options => [ sort keys %unknown ]) : ()),
                (defined $owner_why ? (ownership_warning => $owner_why) : ()),
            };
        }
        else {
            warn "Allowlist: skipping malformed line: $line\n";
        }
    }
    close $fh;
    _log_ascii_spaces($path, $spaced);

    return (\%allowlist, \%skipped);
}

# Skip the entries whose profile agent.conf does not define (T-059): each is
# removed from $allowlist and given its reason in $skipped, like any other
# skipped entry, so one bad line never fails the whole load or reload. Every
# profile, 'default' included, must be defined (no built-in fallback). Returns
# the names skipped. The executor refuses the same scripts ("undefined
# profile").
sub skip_undefined_profiles ($allowlist, $skipped, $config) {
    my %defined = %{ $config->{profiles} // {} };
    my @gone;
    for my $name (sort keys %$allowlist) {
        my $p = script_profile($name, $allowlist) // 'default';
        next if exists $defined{$p};
        delete $allowlist->{$name};
        $skipped->{$name} = "profile '$p' is not defined in agent.conf";
        warn "Allowlist: skipping '$name' - profile '$p' is not defined in agent.conf\n";
        push @gone, $name;
    }
    return @gone;
}

# scripts.conf as the agent uses it: load_allowlist_full, then the entries
# naming a profile agent.conf lacks are skipped. Dies only when the file
# cannot be read. Used at start-up, on every reload and by self-check.
sub load_scripts ($path, $config) {
    my ($allowlist, $skipped) = load_allowlist_full($path, $config->{script_dirs},
                                                    $config->{script_ownership});
    skip_undefined_profiles($allowlist, $skipped, $config);
    return ($allowlist, $skipped);
}

# Why an 'input=' value in scripts.conf is not usable, or undef when it is:
# context, raw, raw:<name> (name as for an input field) or fields.
sub input_mode_problem ($value) {
    return if $value =~ /\A(?:context|raw|fields)\z/;
    if ($value =~ /\Araw:(.*)\z/s) {
        my $f = $1;
        return if $f =~ /\A[A-Za-z0-9_.-]{1,64}\z/ && $f ne '.' && $f ne '..';
        return "its input=raw:<name> field name is not valid (allowed: A-Z a-z 0-9 _ . -, 1-64 characters)";
    }
    my $shown = length $value > 40 ? substr($value, 0, 40) . '...' : $value;
    return "its input mode '$shown' is not one of context, raw, raw:<name>, fields";
}

# Why an 'output=' value in scripts.conf is not usable, or undef when it is:
# stored (the default) or confidential (T-053).
sub output_mode_problem ($value) {
    return if $value =~ /\A(?:stored|confidential)\z/;
    my $shown = length $value > 40 ? substr($value, 0, 40) . '...' : $value;
    return "its output mode '$shown' is not one of stored, confidential";
}

# Why a 'dispatchers=' value in scripts.conf is not usable, or undef when it is:
# one or more dispatcher ids, comma-separated, no spaces, each a valid
# dispatcher id (AgentPairing::valid_dispatcher_id), the whole shorter than
# VALLEN. The executor applies the same rule (dispatchers_ok in
# src/ctrl-exec-executor.c; t/exec-conformance.t).
sub dispatchers_problem ($value) {
    my @ids = split /,/, $value, -1;
    return if length $value < VALLEN && @ids
           && !grep { !Exec::Agent::AgentPairing::valid_dispatcher_id($_) } @ids;
    my $shown = length $value > 40 ? substr($value, 0, 40) . '...' : $value;
    return "its dispatchers= value '$shown' is not a comma-separated list of dispatcher ids"
         . ' (each: a letter or digit, then letters, digits, . _ -, at most 64 characters)';
}

# The reason text for a path outside script_dirs, shared by the load-time skip
# and the execution-time re-check.
sub not_in_dirs_reason ($path, $dirs) {
    return "'$path' is not under script_dirs (" . join(':', @$dirs) . ')';
}

# Why a run of $name is refused, for "script not permitted: <reason>":
# the recorded skip reason, an execution-time script_dirs rejection, or
# 'not in scripts.conf' for a name the allowlist has never heard of.
# The ownership rule is a reason only when $ownership is 'strict'; with 'warn' a
# script that breaks it is not refused.
sub not_permitted_reason ($name, $allowlist, $skipped = undef, $script_dirs = undef,
                          $ownership = 'warn') {
    return 'not in scripts.conf' unless defined $name && $name =~ /^[\w-]+$/;
    $ownership //= 'warn';
    return $skipped->{$name} if $skipped && defined $skipped->{$name};
    my $entry = $allowlist->{$name};
    return 'not in scripts.conf' unless defined $entry;
    my $path = ref $entry eq 'HASH' ? $entry->{path} : $entry;
    if (defined $path && $script_dirs && !_path_in_dirs($path, $script_dirs)) {
        return not_in_dirs_reason($path, $script_dirs);
    }
    if (defined $path && $ownership eq 'strict'
        && defined(my $why = script_owner_problem($path))) {
        return $why;
    }
    return 'not in scripts.conf';
}

# ---- script ownership (T-045) ------------------------------------------------
#
# An allowlisted script, and every directory from / down to it, must be owned by
# root and writable by neither group nor other, and the script must be a regular
# file - otherwise a user who can write any of them can change what root (or a
# run_as profile) runs. This holds whatever the profile's run_as: scripts.conf
# is root's policy, so its scripts are root's files.
#
# The privileged executor enforces this rule before every run (it is the
# authority; src/ctrl-exec-executor.c script_trust_check). The front end applies
# the SAME rule at allowlist load and before each run, so a refused script is
# reported early ("script not permitted: <reason>", self-check) and, without an
# executor (direct mode), is never run. KEEP IN SYNC WITH the C walk: the same
# path walk, the same check order, the same reason texts
# (t/exec-ownership-parity.t compares the two).
#
# Symbolic links on the path are followed, but only once the directory holding
# the link has passed the rule (so only root can have made or changed the link);
# the link's target is then walked with the same rule. More than MAX_SYMLINKS
# links is refused, as the kernel does.

use constant MAX_SYMLINKS => 40;

# Test seams - never set outside tests. Owners trusted in place of root, and a
# directory whose ancestors are not checked (tests cannot create a root-owned
# directory chain without root).
our @TRUSTED_OWNERS = (0);
our $TRUSTED_TOP;

# The reason text when one node on the path breaks the rule, or undef. $want is
# 'dir' or 'file'. Order of checks: type, owner, world-writable, group-writable.
sub _owner_node_problem ($shown, $st, $want, $exempt) {
    my ($dev, $ino, $mode, $uid) = @{$st}[0, 1, 2, 4];
    if ($want eq 'file') {
        return "'$shown' is not a regular file" unless Fcntl::S_ISREG($mode);
    }
    else {
        return "'$shown' is not a directory" unless Fcntl::S_ISDIR($mode);
        return if $exempt->{"$dev:$ino"};
    }
    return "'$shown' is owned by uid $uid, not root"
        unless grep { $_ == $uid } @TRUSTED_OWNERS;
    return "'$shown' is world-writable" if $mode & 0002;
    return "'$shown' is group-writable" if $mode & 0020;
    return;
}

# dev:ino of each strict ancestor of $TRUSTED_TOP (test seam), else empty.
sub _owner_exempt_dirs () {
    return {} unless defined $TRUSTED_TOP;
    my $top = abs_path($TRUSTED_TOP) // return {};
    my %ex;
    my @parts = grep { length } split m{/}, $top;
    pop @parts;
    my $p = '';
    for my $d ('', @parts) {
        $p .= "/$d" if length $d;
        my @st = stat(length $p ? $p : '/') or last;
        $ex{"$st[0]:$st[1]"} = 1;
    }
    return \%ex;
}

# The full verdict on a script path:
#   ('ok')               the path passes the rule
#   ('deny', $reason)    it breaks the rule; $reason names the path and the rule
#   ('unknown', $error)  it cannot be examined (missing, or a directory this
#                        process cannot search) - the front end gives no verdict
#                        and leaves the decision to the executor (or to the
#                        exec, which fails for the same reason)
sub script_owner_check ($path) {
    return ('unknown', "'$path' is not an absolute path") unless $path =~ m{^/};
    my $exempt = _owner_exempt_dirs();
    my @todo   = grep { length } split m{/}, $path;
    my $cur    = '/';
    my $links  = 0;

    my @st = lstat '/' or return ('unknown', "'/': $!");
    if (defined(my $p = _owner_node_problem('/', \@st, 'dir', $exempt))) {
        return ('deny', $p);
    }
    my $final;
    while (@todo) {
        my $c = shift @todo;
        my $want = @todo ? 'dir' : 'file';
        next if $c eq '.';
        my $next;
        if ($c eq '..') {
            ($next = $cur) =~ s{/[^/]*$}{};
            $next = '/' unless length $next;
        }
        else {
            $next = $cur eq '/' ? "/$c" : "$cur/$c";
        }
        @st = lstat $next or return ('unknown', "'$next': $!");
        if (Fcntl::S_ISLNK($st[2])) {
            return ('deny', "'$next' has too many levels of symbolic links")
                if ++$links > MAX_SYMLINKS;
            my $t = readlink $next;
            return ('unknown', "'$next': $!") unless defined $t;
            if ($t =~ m{^/}) {
                $cur = '/';
                @st = lstat '/' or return ('unknown', "'/': $!");
                if (defined(my $p = _owner_node_problem('/', \@st, 'dir', $exempt))) {
                    return ('deny', $p);
                }
            }
            unshift @todo, grep { length } split m{/}, $t;
            next;
        }
        if (Fcntl::S_ISDIR($st[2]) || $want eq 'dir') {
            # A directory to descend into; a non-directory with more to come is
            # refused here as "not a directory".
            if (defined(my $p = _owner_node_problem($next, \@st, 'dir', $exempt))) {
                return ('deny', $p);
            }
            $cur = $next;
            next;
        }
        if (defined(my $p = _owner_node_problem($next, \@st, 'file', $exempt))) {
            return ('deny', $p);
        }
        $final = $next;
    }
    # The walk ended on a directory ("/", "dir/", "dir/.", "dir/..").
    return ('deny', "'$cur' is not a regular file") unless defined $final;
    return ('ok');
}

# The reason a script path breaks the ownership rule, or undef when it passes
# or cannot be examined here (see script_owner_check).
sub script_owner_problem ($path) {
    my ($verdict, $why) = script_owner_check($path);
    return $verdict eq 'deny' ? $why : undef;
}

# Log each skipped scripts.conf entry once (the caller calls this once per load:
# at start-up and on each reload), with the reason a run of it will be given.
sub log_skipped ($skipped) {
    for my $name (sort keys %{ $skipped // {} }) {
        Exec::Log::log_action('WARNING', {
            ACTION => 'allowlist-skip',
            SCRIPT => $name,
            REASON => $skipped->{$name},
        });
    }
}

# Log each dispatchers= id that is not in the trusted-dispatcher map (T-063),
# once per load, like log_skipped. The entry is kept: pairing that dispatcher
# later enables it. $trusted is the whole map as loaded
# ({ '<ca-fpr> <serial>' => '<id>' }); only its ids matter.
sub log_unknown_dispatchers ($allowlist, $trusted) {
    my %known = map { $_ => 1 } values %{ $trusted // {} };
    for my $name (sort keys %{ $allowlist // {} }) {
        for my $id (@{ script_dispatchers($name, $allowlist) // [] }) {
            next if $known{$id};
            Exec::Log::log_action('WARNING', {
                ACTION     => 'allowlist-unknown-dispatcher',
                SCRIPT     => $name,
                DISPATCHER => $id,
                REASON     => "dispatchers= names '$id', which is not in the trusted-dispatcher "
                            . 'map; it runs for that id once a dispatcher is paired with it',
            });
        }
    }
}

# Log each allowlisted script that breaks the ownership rule but runs anyway
# (script_ownership = warn, T-054). Called once per load, like log_skipped -
# never per run.
sub log_ownership_warnings ($allowlist) {
    for my $name (sort keys %{ $allowlist // {} }) {
        my $e = $allowlist->{$name};
        next unless ref $e eq 'HASH' && defined $e->{ownership_warning};
        Exec::Log::log_action('WARNING', {
            ACTION => 'script-ownership',
            SCRIPT => $name,
            REASON => $e->{ownership_warning},
            MODE   => 'warn',
        });
    }
}

# Log each unknown key=value option on an allowlisted scripts.conf entry, once
# per load (T-063): a misspelt option would otherwise be ignored without a
# word. The entry is kept and runs as before.
sub log_unknown_options ($allowlist) {
    for my $name (sort keys %{ $allowlist // {} }) {
        for my $key (@{ script_unknown_options($name, $allowlist) }) {
            Exec::Log::log_action('WARNING', {
                ACTION => 'allowlist-unknown-option',
                NAME   => $name,
                OPTION => $key,
            });
        }
    }
}

# Where the trusted-dispatcher map and the revocation list are, as agent.conf
# sets them or by default.
sub trusted_dispatchers_path ($config) {
    return $config->{trusted_dispatchers_path} // '/var/lib/ctrl-exec-agent/ctrl-exec-dispatchers';
}

sub revoked_serials_path ($config) {
    return $config->{revoked_serials} // '/etc/ctrl-exec-agent/revoked-serials';
}

# The ids of the paired dispatchers, as { id => 1 }: the trusted map read
# without the CA bundle, so the caller never rewrites the map (serve upgrades
# it). Used to point out a dispatchers= id that no paired dispatcher has.
sub paired_dispatcher_ids ($config) {
    return { map { $_ => 1 } values %{ Exec::Agent::AgentPairing::load_trusted_dispatchers(
        path => trusted_dispatchers_path($config)) } };
}

# What is worth a warning about one allowlisted script, as a list of
#   { kind => 'ownership' | 'unknown-dispatcher' | 'unknown-option',
#     value => <reason | dispatcher id | option key>, text => <warning text> }
# in that order. $paired is paired_dispatcher_ids. self-check prints each text
# as "[warning: <text>]"; doctor turns each into a finding.
sub script_warnings ($name, $allowlist, $paired) {
    my @w;
    if (defined(my $owner = script_ownership_warning($name, $allowlist))) {
        push @w, { kind => 'ownership', value => $owner, text => $owner };
    }
    for my $id (grep { !$paired->{$_} } @{ script_dispatchers($name, $allowlist) // [] }) {
        push @w, { kind => 'unknown-dispatcher', value => $id,
                   text => "dispatcher '$id' is not in the trusted map" };
    }
    for my $key (@{ script_unknown_options($name, $allowlist) }) {
        push @w, { kind => 'unknown-option', value => $key, text => "unknown option '$key'" };
    }
    return @w;
}

# The allowlisted scripts (sorted) that declare a profile other than 'default'
# while executor_socket is unset: only the executor applies profiles, so these
# run as the unprivileged agent user. serve warns about them; doctor reports them.
sub profiled_without_executor ($config, $allowlist) {
    return () if $config->{executor_socket};
    my @names = sort grep { (script_profile($_, $allowlist) // 'default') ne 'default' } keys %$allowlist;
    return @names;
}

# The unknown option keys recorded for a script at load (sorted), or [].
sub script_unknown_options ($name, $allowlist) {
    my $e = $allowlist->{$name};
    return ref $e eq 'HASH' ? ($e->{unknown_options} // []) : [];
}

# The ownership warning recorded for a script at load (script_ownership =
# warn), or undef.
sub script_ownership_warning ($name, $allowlist) {
    my $e = $allowlist->{$name};
    return ref $e eq 'HASH' ? $e->{ownership_warning} : undef;
}

# Check whether a script name is permitted
# Returns the script path if permitted, undef otherwise
#
# Optional: script_dirs => \@dirs  re-validates path at execution time
sub validate_script ($name, $allowlist, $script_dirs = undef) {
    return unless defined $name && $name =~ /^[\w-]+$/;
    my $entry = $allowlist->{$name};
    return unless defined $entry;
    # Entries are { path, profile } records; tolerate a bare path string in case
    # an older caller still passes one.
    my $path = ref $entry eq 'HASH' ? $entry->{path} : $entry;
    return unless defined $path;
    if ($script_dirs && !_path_in_dirs($path, $script_dirs)) {
        warn "validate_script: '$name' path rejected at execution time - not in script_dirs: $path\n";
        return;
    }
    return $path;
}

# The profile name assigned to a script in the allowlist ('default' when unset).
sub script_profile ($name, $allowlist) {
    my $entry = $allowlist->{$name};
    return unless defined $entry;
    return ref $entry eq 'HASH' ? ($entry->{profile} // 'default') : 'default';
}

# The input mode of a script ('context' when unset): context, raw, raw:<name>
# or fields (T-013).
sub script_input_mode ($name, $allowlist) {
    my $entry = $allowlist->{$name};
    return 'context' unless ref $entry eq 'HASH';
    return $entry->{input} // 'context';
}

# The output mode of a script ('stored' when unset): stored or confidential
# (T-053). A confidential script's output goes to the caller and nowhere else.
sub script_output_mode ($name, $allowlist) {
    my $entry = $allowlist->{$name};
    return 'stored' unless ref $entry eq 'HASH';
    return $entry->{output} // 'stored';
}

# The dispatcher ids a script is limited to (dispatchers=, T-063), as an
# arrayref, or undef when it has no limit (every trusted dispatcher).
sub script_dispatchers ($name, $allowlist) {
    my $entry = $allowlist->{$name};
    return ref $entry eq 'HASH' ? $entry->{dispatchers} : undef;
}

# Whether $dispatcher - the id the agent resolved from its own trusted map for
# this connection, never one the request names - may run and see $name.
sub script_permits_dispatcher ($name, $allowlist, $dispatcher) {
    my $ids = script_dispatchers($name, $allowlist) // return 1;
    return 0 unless defined $dispatcher;
    return (grep { $_ eq $dispatcher } @$ids) ? 1 : 0;
}

# Cross-check the allowlist against the defined profiles: every script's profile
# must be defined in agent.conf. This includes 'default' (the profile an
# unannotated script resolves to) - there is NO implicit built-in default, so an
# unannotated script with no [profile default] configured is reported here.
# Returns a list of "script -> profile" strings for any that are not defined
# (empty when all resolve). Fail-closed: callers (serve startup, self-check)
# treat a non-empty result as a fatal config error rather than silently running
# an undefined - possibly over-permissive - profile.
sub validate_profiles ($allowlist, $config) {
    my %defined = %{ $config->{profiles} // {} };
    my @unknown;
    for my $name (sort keys %$allowlist) {
        my $p = script_profile($name, $allowlist) // 'default';
        push @unknown, "$name -> $p" unless exists $defined{$p};
    }
    return @unknown;
}

# Settings the running process has already acted on and cannot change without a
# restart: the listener is bound to 'port' and holds the TLS identity loaded from
# 'cert', 'key' and 'ca'. A reload keeps the running value of these and says so.
use constant RESTART_ONLY_KEYS => qw(port cert key ca);

# Plan a reload of agent.conf and scripts.conf (SIGHUP, or either file changed
# on disk, T-059). Nothing is applied here: the caller swaps the result in only
# when this returns.
#
#   reload_plan($config_path, $allowlist_path, $old_config, $old_allowlist, $old_skipped)
#     -> { config => \%new, allowlist => \%allow, skipped => \%why, notes => [ ... ] }
#
# Dies, leaving the caller's old config in force, when agent.conf cannot be
# parsed or validated. A scripts.conf entry naming a profile the new agent.conf
# does not define is skipped with that reason (T-059; it used to fail the whole
# reload). A scripts.conf that cannot be read does not by itself block the
# reload: the previous allowlist stays, held to the new profiles, and the plan
# says so in notes. Restart-only settings that changed keep their running value
# in the returned config and add a note.
sub reload_plan ($config_path, $allowlist_path, $old_config, $old_allowlist, $old_skipped = undef) {
    my $config = load_config($config_path);   # dies on parse/validation error
    my @notes;

    my ($allowlist, $skipped) = eval { load_scripts($allowlist_path, $config) };
    unless ($allowlist) {
        my $err = $@ || 'unknown error'; chomp $err;
        push @notes, "allowlist reload failed, keeping the previous allowlist: $err";
        # Copies: the running allowlist must not change under the caller.
        $allowlist = { %$old_allowlist };
        $skipped   = { %{ $old_skipped // {} } };
        # The previous allowlist is held to the new agent.conf: a script whose
        # profile it no longer defines is skipped, never run without one.
        skip_undefined_profiles($allowlist, $skipped, $config);
    }

    for my $k (RESTART_ONLY_KEYS) {
        my ($old, $new) = ($old_config->{$k}, $config->{$k});
        next if !defined $old && !defined $new;
        next if defined $old && defined $new && $old eq $new;
        push @notes, "'$k' changed in agent.conf but needs a restart to take effect;"
                   . " keeping the running value";
        if   (defined $old) { $config->{$k} = $old }
        else                { delete $config->{$k} }
    }

    return { config => $config, allowlist => $allowlist, skipped => $skipped, notes => \@notes };
}

# Return true if $path is under any directory in @$dirs.
#
# When the script exists - the case that matters at execution time - the path
# and each directory are resolved with abs_path so symlinks and '..' are
# collapsed: an allowlist entry pointing at a symlink that escapes an approved
# directory, or one using '..' to climb out, is then correctly rejected (a
# plain string prefix would miss both). When the path does not exist (e.g. a
# not-yet-installed script being filtered at config load time) it falls back
# to the literal path; such an entry cannot be executed anyway, and once the
# file exists the execution-time check resolves it.
sub _path_in_dirs ($path, $dirs) {
    my $real = abs_path($path) // $path;
    for my $dir (@$dirs) {
        my $rdir = abs_path($dir) // $dir;
        $rdir =~ s{/+$}{};   # strip trailing slash
        return 1 if $real eq $rdir || index($real, "$rdir/") == 0;
    }
    return 0;
}

# Canonicalise an IPv4 dotted-quad: exactly four numeric octets, each 0-255,
# with insignificant leading zeros stripped ("10.00.0.0" -> "10.0.0.0"). Returns
# the canonical string, or undef if the address is not a well-formed IPv4. Used
# at config load so ip_allowed only ever compares canonical octets.
sub _normalize_ipv4 ($addr) {
    return unless defined $addr;
    my @oct = split /\./, $addr, -1;
    return unless @oct == 4;
    for my $o (@oct) {
        return unless $o =~ /^\d{1,3}$/ && $o <= 255;
    }
    return join '.', map { $_ + 0 } @oct;
}

# Check whether a peer IP is permitted by the allowed_ips list.
# Returns 1 if the IP matches any entry, 0 otherwise.
# Supports exact IPs and CIDR prefixes /8, /16, /24 only.
# Invalid entries are filtered out and canonicalised at config load time, so
# every entry here is a well-formed dotted-quad with no leading zeros; the live
# peer IP from the socket is likewise canonical, so string-eq octet matching is
# sound. IPv6 addresses (containing ':') return 0 silently.
sub ip_allowed ($ip, $allowed_ref) {
    # IPv6: not supported - return 0 silently
    return 0 if $ip =~ /:/;

    for my $entry (@$allowed_ref) {
        if ($entry !~ m{/}) {
            # Exact IP match
            return 1 if $ip eq $entry;
        }
        else {
            my ($network, $prefix_len) = split m{/}, $entry, 2;

            # Unsupported prefix lengths were filtered at load time; skip silently
            next unless defined $prefix_len && $prefix_len =~ /^\d+$/ &&
                        grep { $prefix_len == $_ } (8, 16, 24);

            my @ip_oct  = split /\./, $ip,      4;
            my @net_oct = split /\./, $network,  4;

            if ($prefix_len == 8) {
                return 1 if $ip_oct[0] eq $net_oct[0];
            }
            elsif ($prefix_len == 16) {
                return 1 if $ip_oct[0] eq $net_oct[0]
                         && $ip_oct[1] eq $net_oct[1];
            }
            elsif ($prefix_len == 24) {
                return 1 if $ip_oct[0] eq $net_oct[0]
                         && $ip_oct[1] eq $net_oct[1]
                         && $ip_oct[2] eq $net_oct[2];
            }
        }
    }

    return 0;
}

1;
